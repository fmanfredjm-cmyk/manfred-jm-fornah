
class VoiceService {
  private synth: SpeechSynthesis;
  private voice: SpeechSynthesisVoice | null = null;
  private enabled: boolean = false;

  constructor() {
    this.synth = window.speechSynthesis;
    this.initVoice();
  }

  private initVoice() {
    const updateVoices = () => {
      const voices = this.synth.getVoices();
      // Prefer a deep/neutral male voice for the "Oracle" feel or a clear professional voice
      this.voice = voices.find(v => v.name.includes('Google UK English Male') || v.name.includes('Male')) || voices[0];
    };

    updateVoices();
    if (this.synth.onvoiceschanged !== undefined) {
      this.synth.onvoiceschanged = updateVoices;
    }
    
    // Check local storage for preference
    const saved = localStorage.getItem('singularity_voice_enabled');
    this.enabled = saved === 'true';
  }

  setEnabled(enabled: boolean) {
    this.enabled = enabled;
    localStorage.setItem('singularity_voice_enabled', String(enabled));
    if (!enabled) {
      this.synth.cancel();
    }
  }

  isEnabled() {
    return this.enabled;
  }

  speak(text: string, force: boolean = false) {
    if (!this.enabled && !force) return;
    
    // Cancel existing speech
    this.synth.cancel();

    // Clean text (remove URLs, excessive symbols)
    const cleanText = text.replace(/https?:\/\/\S+/g, '').replace(/[^\w\s.,!?-]/g, ' ');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    if (this.voice) {
      utterance.voice = this.voice;
    }
    utterance.rate = 0.95; // Slightly slower for "AI authority" feel
    utterance.pitch = 0.9; // Lower pitch
    
    this.synth.speak(utterance);
  }

  announceAlert(match: string, market: string, odds: number) {
    this.speak(`Alpha signal detected. ${match}. Market: ${market}. Odds: ${odds}. Synchronizing execution.`);
  }
}

export const voiceService = new VoiceService();
