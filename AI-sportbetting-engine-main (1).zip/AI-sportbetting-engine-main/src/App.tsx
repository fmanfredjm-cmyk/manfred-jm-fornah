import React, { useState, useEffect, useRef } from "react";
import { io } from "socket.io-client";
import {
  Trophy,
  Target,
  BarChart3,
  AlertCircle,
  TrendingUp,
  RefreshCcw,
  Search,
  Filter,
  ArrowUpRight,
  ArrowRight,
  ShieldCheck,
  CheckCircle,
  Calendar,
  X,
  Sparkles,
  ChevronRight,
  TrendingDown,
  Clock,
  Briefcase,
  Send,
  User as UserIcon,
  LogOut,
  MessageSquare,
  Globe,
  Database,
  Cpu,
  Terminal,
  Infinity,
  Dna,
  ShieldAlert,
  Zap,
  Activity,
  Radio,
  Timer,
  Telescope,
  CheckSquare,
  ListTodo,
  Receipt,
  Sun,
  Moon,
  HelpCircle,
  CreditCard,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";
import {
  signInWithPopup,
  onAuthStateChanged,
  signOut,
  User as FirebaseUser,
} from "firebase/auth";
import {
  collection,
  addDoc,
  query,
  orderBy,
  onSnapshot,
  limit,
  serverTimestamp,
  doc,
  setDoc,
  getDoc,
  deleteDoc,
} from "firebase/firestore";
import { auth, db, googleProvider, handleFirestoreError } from "./lib/firebase";
import { voiceService } from "./services/voiceService";
import { puter } from "@heyputer/puter.js";

// Interfaces
interface LiveMatch {
  id: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  time: string;
  league: string;
  stats: {
    possession: number;
    corners: { home: number; away: number };
    shotsOnTarget: { home: number; away: number };
    cards: { home: number; away: number };
  };
  inGamePredictions: {
    market: string;
    prediction: string;
    prob: number;
    odds: number;
    bookmaker?: string;
  }[];
}

interface ElitePick {
  id: string;
  match: string;
  market: string;
  odds: number;
  prob: number;
  strength: { home: number; away: number };
  reasoning: string;
  confidence: string;
  type: string;
}

interface UltraSafeCombo {
  name: string;
  totalOdds: number;
  combinedProb: number;
  selections: ElitePick[];
}

interface AIFuture {
  id: string;
  title: string;
  projection: string;
  prob: number;
  temporalConfidence: string;
  simulations: string;
  riskFactor: string;
  impact: string;
  narrative: string;
}

interface Signal {
  id: number;
  match: string;
  odds: number;
  modelProb: number;
  impliedProb: number;
  edge: number;
  decision: string;
  sport: string;
  league: string;
  confidence: string;
  type?: "SAFE" | "VAL" | "EDGE" | "NONE";
  market?: string;
  bookmaker?: string;
  reliability: number;
  variance: number;
}

interface Accumulator {
  id: string;
  name: string;
  type: string;
  selections: {
    id: number;
    match: string;
    odds: number;
    prob: number;
    league: string;
  }[];
  totalOdds: number;
  combinedProb: number;
  confidence: string;
  verified: boolean;
  timestamp: string;
}

interface Match {
  id: number;
  homeTeam: string;
  awayTeam: string;
  league: string;
  time: string;
  status: string;
  sport: string;
}

interface Metrics {
  accuracy: {
    overall: number;
    football: number;
    basketball: number;
  };
  roi: {
    total: number;
    thisMonth: number;
  };
  signalsProcessed: number;
  profitableSignals: number;
  marketVolatity: string;
  sharpeRatio: number;
  neuralAmmunition?: {
    reserve: number;
    active: number;
    dynamic: string;
  };
  dataRoutes?: {
    id: string;
    source: string;
    latency: string;
    load: number;
  }[];
}

interface BettingRules {
  valueThreshold: number;
  edgeThreshold: number;
  minProbability: number;
}

interface ChatMessage {
  id?: string;
  userId: string;
  text: string;
  sender: "user" | "ai";
  timestamp: any;
  isSearch?: boolean;
}

interface EvolutionStatus {
  lastRebuild: string;
  nextImprovementCycle: string;
  neuralGrowth: number;
  activeSelfCorrections: number;
  totalUpgradesGenerated: number;
}

interface EvolutionLog {
  id: number;
  type: "HEALING" | "UPGRADE" | "SECURITY";
  message: string;
  timestamp: string;
}

interface PredictedError {
  component: string;
  risk: string;
  predictedError: string;
  correctionStrategy: string;
  timeToIncident: string;
}

interface Task {
  id: string;
  text: string;
  completed: boolean;
  createdAt: any;
}

interface TaxRecord {
  id: string;
  year?: number;
  eventName?: string;
  predictionType?: string;
  sport?: string;
  profit: number;
  loss: number;
  notes: string;
  updatedAt: any;
}

const DynamicOdd = ({ price }: { price: number }) => {
  const prevPriceRef = useRef(price);
  const [highlightClass, setHighlightClass] = useState("");

  useEffect(() => {
    if (price > prevPriceRef.current) {
      setHighlightClass(
        "text-emerald-400 font-extrabold shadow-[0_0_15px_rgba(52,211,153,0.8)] scale-110",
      );
      setTimeout(() => setHighlightClass(""), 1000);
    } else if (price < prevPriceRef.current) {
      setHighlightClass(
        "text-red-400 font-extrabold shadow-[0_0_15px_rgba(248,113,113,0.8)] scale-110",
      );
      setTimeout(() => setHighlightClass(""), 1000);
    }
    prevPriceRef.current = price;
  }, [price]);

  return (
    <div
      className={`text-lg font-mono font-bold text-white transition-all duration-300 ${highlightClass}`}
    >
      {parseFloat(price.toString()).toFixed(2)}
    </div>
  );
};

export default function App() {
  const [matches, setMatches] = useState<Match[]>([]);
  const [signals, setSignals] = useState<Signal[]>([]);
  const [accumulators, setAccumulators] = useState<Accumulator[]>([]);
  const [liveMatches, setLiveMatches] = useState<LiveMatch[]>([]);
  const [futures, setFutures] = useState<AIFuture[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // New States
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSport, setSelectedSport] = useState<string>("All");
  const [sortBy, setSortBy] = useState<"edge" | "odds" | "prob" | "elite">(
    "edge",
  );
  const [eliteOnly, setEliteOnly] = useState(false);
  const [selectedSignal, setSelectedSignal] = useState<Signal | null>(null);
  const [aiInsights, setAiInsights] = useState<string>("");
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showAddTaxRecord, setShowAddTaxRecord] = useState(false);
  const [newTaxRecord, setNewTaxRecord] = useState({
    eventName: "",
    predictionType: "",
    sport: "Football",
    profit: 0,
    loss: 0,
  });

  const handleCsvUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!user) {
      addNotification("Please sign in to upload data.", "error");
      return;
    }
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split("\n");
        let count = 0;

        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;

          const parts = line.split(",");
          if (parts.length >= 5) {
            await addDoc(collection(db, "users", user.uid, "tax_records"), {
              userId: user.uid,
              eventName:
                parts[0]?.trim().replace(/^"|"$/g, "") || "Imported Event",
              sport: parts[1]?.trim().replace(/^"|"$/g, "") || "Unknown",
              predictionType:
                parts[2]?.trim().replace(/^"|"$/g, "") || "Unknown",
              profit: parseFloat(parts[3]) || 0,
              loss: parseFloat(parts[4]) || 0,
              notes: "Imported via CSV",
              updatedAt: serverTimestamp(),
            });
            count++;
          }
        }
        addNotification(
          `Successfully imported ${count} records from CSV.`,
          "success",
        );
      } catch (err) {
        console.error(err);
        addNotification("Error processing CSV upload.", "error");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };
  const [bettingRules, setBettingRules] = useState<BettingRules>({
    valueThreshold: 0.05,
    edgeThreshold: 0.02,
    minProbability: 0.75,
  });
  const [activeTab, setActiveTab] = useState<
    | "signals"
    | "metrics"
    | "chat"
    | "evolution"
    | "accumulators"
    | "live"
    | "futures"
    | "tasks"
    | "taxes"
    | "elite"
  >("elite");
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [puterUser, setPuterUser] = useState<any>(null);
  const [elitePicks, setElitePicks] = useState<ElitePick[]>([]);
  const [ultraSafeCombo, setUltraSafeCombo] = useState<UltraSafeCombo | null>(
    null,
  );
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [useSearch, setUseSearch] = useState(true);
  const [isCalibrating, setIsCalibrating] = useState(false);

  const [evolutionStats, setEvolutionStats] = useState<EvolutionStatus | null>(
    null,
  );
  const [evolutionLogs, setEvolutionLogs] = useState<EvolutionLog[]>([]);
  const [predictedErrors, setPredictedErrors] = useState<PredictedError[]>([]);
  const [isAnalyzingEvolution, setIsAnalyzingEvolution] = useState(false);
  const [neuralState, setNeuralState] = useState<any>(null);
  const [isCalibratingNeural, setIsCalibratingNeural] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(voiceService.isEnabled());

  const [health, setHealth] = useState<any>(null);

  // Todo, Tax & Onboarding States
  const [tasks, setTasks] = useState<Task[]>([]);
  const [taxRecords, setTaxRecords] = useState<TaxRecord[]>([]);
  const [theme, setTheme] = useState<"light" | "dark">("dark");
  const [onboardingStep, setOnboardingStep] = useState<number | null>(null);
  const [newTask, setNewTask] = useState("");
  const [realTimeOdds, setRealTimeOdds] = useState<any[]>([]);
  const [isFetchingOdds, setIsFetchingOdds] = useState(false);
  const [decodingStatus, setDecodingStatus] = useState<
    Record<string, "idle" | "decoding" | "decoded">
  >({});
  const [notifications, setNotifications] = useState<
    { id: number; msg: string; type: "success" | "alert" | "error" }[]
  >([]);
  const [expandedMatch, setExpandedMatch] = useState<any>(null);

  const addNotification = React.useCallback(
    (msg: string, type: "success" | "alert" | "error" = "success") => {
      const id = Date.now();
      setNotifications((prev) => [...prev, { id, msg, type }]);
      setTimeout(() => {
        setNotifications((prev) => prev.filter((n) => n.id !== id));
      }, 3000);
    },
    [],
  );

  const fetchOdds = React.useCallback(
    async (isManualRefresh = false) => {
      if (!isManualRefresh && activeTab !== "live") return;

      setIsFetchingOdds(true);
      try {
        let sportKey = "upcoming";
        if (selectedSport === "Football") sportKey = "soccer_global";
        else if (selectedSport === "Basketball") sportKey = "basketball_nba";
        else if (selectedSport === "Tennis") sportKey = "tennis_atp";

        const res = await fetch(`/api/odds/${sportKey}`);
        if (res.ok) {
          const data = await res.json();
          setRealTimeOdds(data.slice(0, 40));
        }
      } catch (err) {
        console.warn("Failed to fetch specific odds api");
      } finally {
        setIsFetchingOdds(false);
      }
    },
    [activeTab, selectedSport],
  );

  const handleDecodeAcc = (accId: string) => {
    setDecodingStatus((prev) => ({ ...prev, [accId]: "decoding" }));
    addNotification("Quantum decryption initiated for accumulator.", "alert");
    setTimeout(() => {
      setDecodingStatus((prev) => ({ ...prev, [accId]: "decoded" }));
      addNotification("Accumulator decoded successfully!", "success");
    }, 2500);
  };

  useEffect(() => {
    // 15 Minutes Auto-Restart / Cache Clear to ensure optimal app health
    const restartTimer = setInterval(
      () => {
        console.log(
          "15-minute system auto-refresh initiated to maintain health...",
        );
        window.location.reload();
      },
      15 * 60 * 1000,
    );

    return () => clearInterval(restartTimer);
  }, []);

  useEffect(() => {
    let isMounted = true;
    let pollInterval: NodeJS.Timeout;

    const intervalFetch = async () => {
      await fetchOdds();
    };

    intervalFetch();
    pollInterval = setInterval(intervalFetch, 10000); // Poll every 10 seconds

    return () => {
      isMounted = false;
      clearInterval(pollInterval);
    };
  }, [fetchOdds]);

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove("light", "dark");
    root.classList.add(theme);
    root.style.colorScheme = theme;
  }, [theme]);

  const calibrateThresholds = async () => {
    if (!metrics) return;
    setIsCalibrating(true);

    try {
      // Simulate Deep Computation
      await new Promise((resolve) => setTimeout(resolve, 2000));

      // Heuristic Logic based on ROI and Accuracy
      // If accuracy is high (>65%), we can lower threshold for more volume
      // If ROI is high (>10%), we can be more selective to protect capital

      let newVal = 0.05;
      let newEdge = 0.02;

      if (metrics.accuracy.overall > 0.65) {
        newVal = 0.04; // More aggressive
        newEdge = 0.015;
      }

      if (metrics.roi.total > 10) {
        newVal += 0.02; // Be more selective to lock in gains
      }

      const updatedRules = {
        valueThreshold: newVal,
        edgeThreshold: newEdge,
      };

      setBettingRules(updatedRules);

      if (user) {
        const userRef = doc(db, "users", user.uid);
        await setDoc(userRef, { bettingRules: updatedRules }, { merge: true });
      }
    } catch (error) {
      console.error("Calibration failed:", error);
    } finally {
      setIsCalibrating(false);
    }
  };

  const triggerEvolutionScan = async () => {
    setIsAnalyzingEvolution(true);
    try {
      // Use Gemini to analyze the "Current State" and propose improvements
      const prompt = `Analyze this betting engine system state:
      Accuracy: ${metrics?.accuracy.overall}
      ROI: ${metrics?.roi.total}%
      Growth: ${evolutionStats?.neuralGrowth}
      
      Generate a technical "Evolution Upgrade" log message indicating a self-correction or improvement that should happen.
      Include a futuristic/technical explanation.`;

      let upgradeMessage = "";
      try {
        const res = await fetch("/api/ai/evolution", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: prompt }),
        });
        if (!res.ok) throw new Error("Evolution vertex failed");
        const data = await res.json();
        upgradeMessage =
          data.text ||
          "Neural architecture synchronized. Optimizing signal throughput.";
      } catch (err) {
        console.warn("Evolution AI fallback to puter", err);
        try {
          const puterRes = await puter.ai.chat(prompt);
          upgradeMessage =
            typeof puterRes?.message?.content === "string"
              ? puterRes.message.content
              : typeof puterRes === "string"
                ? puterRes
                : "Neural architecture synchronized via Puter.";
        } catch (pErr) {
          upgradeMessage =
            "Neural architecture synchronized. Systems optimized offline.";
        }
      }

      // Simulate the rebuild process
      await new Promise((resolve) => setTimeout(resolve, 3000));

      const newLog: EvolutionLog = {
        id: Date.now(),
        type: "UPGRADE",
        message: upgradeMessage,
        timestamp: new Date().toISOString(),
      };

      setEvolutionLogs((prev) => [newLog, ...prev]);

      // Update stats (simulated growth)
      if (evolutionStats) {
        setEvolutionStats({
          ...evolutionStats,
          neuralGrowth: Math.min(1, evolutionStats.neuralGrowth + 0.01),
          totalUpgradesGenerated: evolutionStats.totalUpgradesGenerated + 1,
        });
      }

      alert("EVOLUTION COMPLETE: " + upgradeMessage);
    } catch (error) {
      console.error("Evolution scan failed:", error);
    } finally {
      setIsAnalyzingEvolution(false);
    }
  };

  const calibrateNeuralEngine = async () => {
    setIsCalibratingNeural(true);
    try {
      const res = await fetch("/api/system/calibrate", { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        setNeuralState(data.stats);
        voiceService.speak(
          "Neural recalibration complete. Weights optimized.",
          true,
        );
      }
    } catch (err) {
      console.error("Calibration failed:", err);
    } finally {
      setIsCalibratingNeural(false);
    }
  };

  const isFetching = useRef(false);
  const fetchEngineData = async (retryCount = 0) => {
    if (isFetching.current && retryCount === 0) return;
    isFetching.current = true;
    if (retryCount === 0) setLoading(true);
    try {
      const res = await fetch("/api/dashboard");

      // Handle the case where the server might be starting up and serving the SPA index
      const contentType = res.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        if (retryCount < 3) {
          console.warn(
            `Non-JSON response from dashboard. Retrying in ${1000 * (retryCount + 1)}ms...`,
          );
          setTimeout(
            () => fetchEngineData(retryCount + 1),
            1000 * (retryCount + 1),
          );
          return;
        }
        const text = await res.text();
        console.error(
          "Dashboard fetch error: Expected JSON but received HTML/Text. First 100 chars:",
          text.substring(0, 100),
        );
        throw new Error(
          "Server returned non-JSON response. This usually means the API route is falling through to the SPA index.",
        );
      }

      if (res.status === 503) {
        const recoveringData = await res.json();
        setHealth(recoveringData.stats);
        logSystemStatus("System is self-healing. Retrying in 4s...", "warn");
        setTimeout(() => {
          isFetching.current = false;
          fetchEngineData();
        }, 4000);
        return;
      }

      if (!res.ok) throw new Error(`Dashboard fetch failed: ${res.status}`);

      const dashboard = await res.json();

      if (
        dashboard.signals &&
        dashboard.signals.length > signals.length &&
        signals.length > 0
      ) {
        const newSignal = dashboard.signals[0];
        voiceService.announceAlert(
          newSignal.match,
          newSignal.market,
          newSignal.odds,
        );
      }

      if (dashboard.matches) setMatches(dashboard.matches);
      if (dashboard.signals) setSignals(dashboard.signals);
      if (dashboard.accumulators) setAccumulators(dashboard.accumulators);
      if (dashboard.live) setLiveMatches(dashboard.live);
      if (dashboard.futures) setFutures(dashboard.futures);
      if (dashboard.metrics) setMetrics(dashboard.metrics);
      if (dashboard.health) setHealth(dashboard.health);
      if (dashboard.evoStats) setEvolutionStats(dashboard.evoStats);
      if (dashboard.evoLogs) setEvolutionLogs(dashboard.evoLogs);
      if (dashboard.evoErrors) setPredictedErrors(dashboard.evoErrors);
      if (dashboard.elitePicks) setElitePicks(dashboard.elitePicks);
      if (dashboard.ultraSafeCombo) setUltraSafeCombo(dashboard.ultraSafeCombo);
      if (dashboard.neuralState) setNeuralState(dashboard.neuralState);

      setLastUpdated(new Date());
    } catch (error: any) {
      console.error("Dashboard fetch error:", error);
      logSystemStatus(`Engine Link Severed: ${error.message}`, "error");
    } finally {
      setLoading(false);
      isFetching.current = false;
    }
  };

  const logSystemStatus = (msg: string, type: "info" | "warn" | "error") => {
    setEvolutionLogs((prev) => [
      {
        id: Date.now(),
        timestamp: new Date().toISOString(),
        message: msg,
        type: type.toUpperCase(),
      },
      ...prev.slice(0, 19),
    ]);
  };

  useEffect(() => {
    let unsubscribeChat: (() => void) | undefined;
    let unsubscribeTasks: (() => void) | undefined;
    let unsubscribeTax: (() => void) | undefined;

    const unsubscribeAuth = onAuthStateChanged(auth, async (u) => {
      setUser(u);

      if (unsubscribeChat) unsubscribeChat();
      if (unsubscribeTasks) unsubscribeTasks();
      if (unsubscribeTax) unsubscribeTax();

      if (u) {
        const userRef = doc(db, "users", u.uid);
        try {
          const userDoc = await getDoc(userRef);
          if (!userDoc.exists()) {
            await setDoc(userRef, {
              email: u.email,
              displayName: u.displayName,
              photoURL: u.photoURL,
              createdAt: serverTimestamp(),
              bettingRules,
              theme: "dark",
              onboardingComplete: false,
            });
            setOnboardingStep(1);
          } else {
            const data = userDoc.data();
            setBettingRules(data.bettingRules || bettingRules);
            if (data.theme) setTheme(data.theme as "light" | "dark");
            if (data.onboardingComplete === false) setOnboardingStep(1);
          }
        } catch (err) {
          handleFirestoreError(err, "write", `users/${u.uid}`);
        }

        const qChat = query(
          collection(db, "users", u.uid, "chat"),
          orderBy("timestamp", "desc"),
          limit(50),
        );
        unsubscribeChat = onSnapshot(qChat, (snapshot) => {
          setChatMessages(
            snapshot.docs
              .map((doc) => ({ id: doc.id, ...doc.data() }) as ChatMessage)
              .reverse(),
          );
        });

        const qTasks = query(
          collection(db, "users", u.uid, "tasks"),
          orderBy("createdAt", "desc"),
        );
        unsubscribeTasks = onSnapshot(qTasks, (snapshot) => {
          setTasks(
            snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }) as Task),
          );
        });

        const qTax = query(
          collection(db, "users", u.uid, "tax_records"),
          orderBy("year", "desc"),
        );
        unsubscribeTax = onSnapshot(qTax, (snapshot) => {
          setTaxRecords(
            snapshot.docs.map(
              (doc) => ({ id: doc.id, ...doc.data() }) as TaxRecord,
            ),
          );
        });
      } else {
        setChatMessages([]);
        setTasks([]);
        setTaxRecords([]);
        setOnboardingStep(null);
      }
    });

    fetchEngineData();
    generateAiFuture();

    const socket = io({
      reconnectionAttempts: 5,
      timeout: 10000,
      transports: ["polling", "websocket"],
    });

    socket.on("connect_error", (err) => {
      console.warn("Socket connection warning:", err.message);
    });

    socket.on("live_match_update", (matches: LiveMatch[]) => {
      setLiveMatches(matches);
    });

    socket.on("live_odds_update", (updates: any[]) => {
      setLiveMatches((prev) =>
        prev.map((match) => {
          const update = updates.find((u) => u.id === match.id);
          if (update) {
            return {
              ...match,
              homeScore:
                update.homeScore !== undefined
                  ? update.homeScore
                  : match.homeScore,
              awayScore:
                update.awayScore !== undefined
                  ? update.awayScore
                  : match.awayScore,
              time: update.time !== undefined ? update.time : match.time,
              inGamePredictions: match.inGamePredictions.map((pred) => {
                const predUpdate = update.predictions.find(
                  (p: any) => p.market === pred.market,
                );
                return predUpdate ? { ...pred, odds: predUpdate.odds } : pred;
              }),
            };
          }
          return match;
        }),
      );
    });

    socket.on("odds_tick", () => {
      fetchEngineData();
    });

    socket.on("system_healing_start", (data: { reason: string }) => {
      logSystemStatus(`HEALING PROTOCOL INITIATED: ${data.reason}`, "warn");
      setHealth((prev: any) =>
        prev ? { ...prev, circuitBreaker: true } : null,
      );
    });

    socket.on("system_healing_complete", (data: { timestamp: string }) => {
      logSystemStatus("SELF-HEALING COMPLETE. ENGINE RE-STABILIZED.", "info");
      setHealth((prev: any) =>
        prev
          ? { ...prev, circuitBreaker: false, lastAutoFix: data.timestamp }
          : null,
      );
      fetchEngineData();
    });

    const tickInterval = setInterval(fetchEngineData, 120000);

    return () => {
      unsubscribeAuth();
      if (unsubscribeChat) unsubscribeChat();
      if (unsubscribeTasks) unsubscribeTasks();
      if (unsubscribeTax) unsubscribeTax();
      socket.disconnect();
      clearInterval(tickInterval);
    };
  }, []);

  useEffect(() => {
    // Check Puter auth status on load
    if (puter.auth.isSignedIn()) {
      puter.auth.getUser().then((u) => setPuterUser(u));
    }
  }, []);

  const renderEliteAnalyst = () => (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Risk Management Header */}
      <div className="bg-gradient-to-br from-emerald-950/40 via-black to-black p-10 rounded-[3rem] border border-emerald-500/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8">
          <div className="px-4 py-2 bg-emerald-500/10 text-emerald-500 text-[10px] font-black rounded-full border border-emerald-500/20 uppercase tracking-widest shadow-[0_0_15px_rgba(16,185,129,0.2)]">
            90%+ Filter Active
          </div>
        </div>

        <div className="flex items-center gap-6 mb-8">
          <div className="p-5 bg-emerald-500 rounded-3xl shadow-[0_0_30px_rgba(16,185,129,0.3)]">
            <ShieldCheck className="w-10 h-10 text-black" />
          </div>
          <div>
            <h2 className="text-4xl font-black text-white italic tracking-tighter uppercase mb-1">
              ELITE RISK ANALYST
            </h2>
            <p className="text-xs text-white/40 uppercase tracking-[0.2em] font-mono">
              Filtering Alpha • Zero-Fatigue Validation • v2.0
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-[10px] text-white/30 uppercase font-bold mb-2">
              Algorithm
            </div>
            <div className="text-sm font-bold text-white">
              Value-Based Exclusion
            </div>
          </div>
          <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-[10px] text-white/30 uppercase font-bold mb-2">
              Criteria
            </div>
            <div className="text-sm font-bold text-white">
              90% Prob | 1.20 - 1.40 Odds
            </div>
          </div>
          <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
            <div className="text-[10px] text-white/30 uppercase font-bold mb-2">
              Market Constraint
            </div>
            <div className="text-sm font-bold text-white">
              DC / Over 1.5 Goals
            </div>
          </div>
        </div>
      </div>

      {/* Elite Picks Board */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {elitePicks.map((pick, i) => (
          <motion.div
            key={pick.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="cursor-pointer bg-black/40 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/10 hover:border-emerald-500/40 transition-all group relative"
            onClick={() => setExpandedMatch(pick)}
          >
            <div className="absolute top-8 right-8">
              <div className="flex items-center gap-1 text-emerald-400">
                <Sparkles className="w-4 h-4 fill-emerald-400" />
                <span className="text-xs font-black italic">
                  CONFIDENCE: {pick.confidence}
                </span>
              </div>
            </div>

            <div className="mb-6">
              <span className="px-3 py-1 bg-white/5 text-white/30 text-[9px] font-black rounded-lg uppercase tracking-wider mb-2 inline-block">
                Elite Signal #{i + 1}
              </span>
              <h3 className="text-2xl font-black text-white italic tracking-tighter uppercase">
                {pick.match}
              </h3>
            </div>

            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="space-y-4">
                <div>
                  <div className="text-[10px] text-white/30 uppercase font-bold mb-1">
                    Proposed Action
                  </div>
                  <div className="text-lg font-black text-emerald-400 italic uppercase">
                    {pick.market}
                  </div>
                </div>
                <div className="flex gap-4">
                  <div>
                    <div className="text-[10px] text-white/30 uppercase font-bold mb-1">
                      Odds
                    </div>
                    <div className="text-2xl font-mono font-bold text-white tracking-tighter">
                      {pick.odds.toFixed(2)}
                    </div>
                    <div className="text-[9px] text-white/40 mt-1 uppercase font-bold tracking-widest">
                      Implied: {((1 / pick.odds) * 100).toFixed(1)}%
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-white/30 uppercase font-bold mb-1">
                      Neural Prob
                    </div>
                    <div className="text-2xl font-mono font-bold text-emerald-400 tracking-tighter">
                      {(pick.prob * 100).toFixed(1)}%
                    </div>
                    <div className="text-[9px] text-emerald-500 mt-1 uppercase font-black tracking-widest">
                      EV+: {((pick.prob * pick.odds - 1) * 100).toFixed(1)}%
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-3xl p-6 border border-white/5 flex flex-col justify-center relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <Target className="w-16 h-16" />
                </div>
                <div className="flex justify-between items-center mb-4 relative z-10">
                  <span className="text-[10px] text-white/30 uppercase font-black">
                    Confidence Matrix
                  </span>
                </div>
                <div className="space-y-4 relative z-10">
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] font-mono text-white/60">
                      <span>STRIKE RATE EST.</span>
                      <span className="text-emerald-400">
                        {(pick.prob * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${pick.prob * 100}%` }}
                        className="h-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.8)]"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] font-mono text-white/60">
                      <span>VALUE EDGE</span>
                      <span className="text-indigo-400">
                        {((pick.prob * pick.odds - 1) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{
                          width: `${Math.min((pick.prob * pick.odds - 1) * 100 * 5, 100)}%`,
                        }}
                        className="h-full bg-indigo-500"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-emerald-500/5 rounded-2xl border border-emerald-500/10 mb-4 flex gap-4 items-center">
              <div className="flex-1">
                <p className="text-[11px] text-emerald-300/80 leading-relaxed font-medium italic">
                  "API Analysis: {pick.reasoning}"
                </p>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                window.open(
                  `https://example.com/bet?market=${encodeURIComponent(pick.market)}&odds=${pick.odds}`,
                  "_blank",
                );
              }}
              className="w-full py-4 mt-2 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 font-black uppercase tracking-widest rounded-xl hover:bg-emerald-500 hover:text-black transition-all flex justify-center items-center gap-2"
            >
              Execute Elite Target <ArrowRight className="w-4 h-4" />
            </button>

            <button className="w-full py-4 bg-white text-black font-black uppercase text-xs rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2">
              Execute Stake Optimization <ArrowUpRight className="w-4 h-4" />
            </button>
          </motion.div>
        ))}
      </div>

      {/* ULTRA SAFE COMBO FOOTER */}
      {ultraSafeCombo && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-emerald-500 p-12 rounded-[4rem] text-black relative overflow-hidden group hover:scale-[1.01] transition-all cursor-pointer"
        >
          <div className="absolute top-0 right-0 p-12 opacity-10 group-hover:opacity-20 transition-opacity">
            <Trophy className="w-48 h-48 -mr-12 -mt-12 rotate-12" />
          </div>

          <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-12">
            <div className="text-center md:text-left">
              <div className="px-5 py-2 bg-black text-white text-[10px] font-black rounded-full uppercase tracking-widest inline-block mb-6">
                Combo Identified
              </div>
              <h2 className="text-6xl font-black italic tracking-tighter uppercase leading-[0.9]">
                ULTRA SAFE
                <br />
                COMBO
              </h2>
              <div className="flex items-center gap-4 mt-6">
                <div className="flex -space-x-3">
                  {[1, 2, 3, 4].map((i) => (
                    <div
                      key={i}
                      className="w-10 h-10 bg-black/10 rounded-full border-2 border-black/20 flex items-center justify-center backdrop-blur-sm"
                    >
                      <CheckSquare className="w-4 h-4 text-black" />
                    </div>
                  ))}
                </div>
                <span className="text-xs font-black uppercase tracking-widest opacity-60">
                  {ultraSafeCombo.selections.length} Elite Matches
                </span>
              </div>
            </div>

            <div className="flex items-center gap-8">
              <div className="text-center">
                <div className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-1">
                  Total Multiplier
                </div>
                <div className="text-7xl font-black tracking-tighter italic">
                  @{ultraSafeCombo.totalOdds.toFixed(2)}
                </div>
              </div>
              <div className="h-24 w-px bg-black/10" />
              <div className="text-center">
                <div className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-1">
                  Aggregated Prob
                </div>
                <div className="text-5xl font-black tracking-tighter">
                  {(ultraSafeCombo.combinedProb * 100).toFixed(1)}%
                </div>
              </div>
            </div>

            <button className="px-10 py-6 bg-black text-white rounded-3xl font-black text-sm uppercase flex items-center gap-3 hover:gap-5 transition-all shadow-2xl">
              Place Ultra Safe Combination <Trophy className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );

  const renderTaxManagement = () => (
    <div className="space-y-6 p-6 bg-black/20 rounded-3xl border border-white/5">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Receipt className="w-6 h-6 text-emerald-400" />
            Accounting & Play Ledger
          </h2>
          <p className="text-sm text-white/40">
            Tracking P/L for year-end reporting & multiple game research
          </p>
        </div>
        <div className="flex gap-2">
          <label className="cursor-pointer px-4 py-2 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-xl text-xs font-bold uppercase hover:bg-indigo-500/20 transition-all flex items-center gap-2">
            Upload CSV
            <input
              type="file"
              accept=".csv"
              className="hidden"
              onChange={handleCsvUpload}
            />
          </label>
          <button
            onClick={() => setShowAddTaxRecord(true)}
            className="px-4 py-2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl text-xs font-bold uppercase hover:bg-emerald-500/20 transition-all"
          >
            Add Record
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {taxRecords.map((record) => (
          <div
            key={record.id}
            className="p-4 bg-[#0F0F11] rounded-2xl border border-white/10 group flex flex-col md:flex-row justify-between md:items-center gap-4"
          >
            <div className="flex-1">
              <div className="flex justify-between items-start mb-2">
                <span className="text-lg font-bold text-white tracking-tight">
                  {record.eventName || `FY ${record.year}`}
                </span>
              </div>
              <div className="flex gap-2 text-[10px] text-white/40 font-mono items-center">
                <span className="bg-white/5 px-2 py-0.5 rounded uppercase tracking-wider">
                  {record.sport || "Unknown"}
                </span>
                <span className="bg-emerald-500/10 text-emerald-500 px-2 py-0.5 rounded uppercase tracking-wider">
                  {record.predictionType || "General Statement"}
                </span>
                <span>
                  {record.updatedAt
                    ? new Date(
                        record.updatedAt.toDate
                          ? record.updatedAt.toDate()
                          : record.updatedAt,
                      ).toLocaleDateString()
                    : "N/A"}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 flex-none">
              <div className="p-2 bg-emerald-500/5 rounded-xl border border-emerald-500/10 w-28">
                <span className="text-[10px] text-emerald-400/60 uppercase block">
                  Profit
                </span>
                <span className="text-lg text-emerald-400 font-mono">
                  ${record.profit.toFixed(2)}
                </span>
              </div>
              <div className="p-2 bg-rose-500/5 rounded-xl border border-rose-500/10 w-28">
                <span className="text-[10px] text-rose-400/60 uppercase block">
                  Loss
                </span>
                <span className="text-lg text-rose-400 font-mono">
                  ${record.loss.toFixed(2)}
                </span>
              </div>
            </div>

            <button
              onClick={() =>
                user &&
                deleteDoc(doc(db, "users", user.uid, "tax_records", record.id))
              }
              className="p-3 bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 rounded-xl transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        ))}
        {taxRecords.length === 0 && (
          <div className="py-12 border border-white/5 border-dashed rounded-3xl text-center text-white/30 uppercase text-sm font-bold tracking-widest">
            No Records Found in Ledger
          </div>
        )}
      </div>
    </div>
  );

  const renderTaskList = () => {
    return (
      <div className="space-y-6 p-6 bg-black/20 rounded-3xl border border-white/5 h-full flex flex-col">
        <div className="mb-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ListTodo className="w-6 h-6 text-indigo-400" />
            Research Quests
          </h2>
          <p className="text-sm text-white/40">
            Manage research tasks and follow-ups
          </p>
        </div>

        <form
          onSubmit={async (e) => {
            e.preventDefault();
            if (!newTask.trim() || !user) return;
            await addDoc(collection(db, "users", user.uid, "tasks"), {
              userId: user.uid,
              text: newTask,
              completed: false,
              createdAt: serverTimestamp(),
            });
            setNewTask("");
          }}
          className="flex gap-2"
        >
          <input
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder="Describe your research task..."
            className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-indigo-500/50 transition-all font-mono"
          />
          <button
            type="submit"
            className="p-3 bg-indigo-500 text-white rounded-xl hover:bg-indigo-400 transition-all"
          >
            <Sparkles className="w-5 h-5" />
          </button>
        </form>

        <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-hide">
          <AnimatePresence>
            {tasks.map((task) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className={`p-4 rounded-2xl border transition-all flex items-center gap-4 group ${
                  task.completed
                    ? "bg-white/5 border-white/5 opacity-50"
                    : "bg-white/10 border-white/20"
                }`}
              >
                <button
                  onClick={() =>
                    user &&
                    setDoc(
                      doc(db, "users", user.uid, "tasks", task.id),
                      { completed: !task.completed },
                      { merge: true },
                    )
                  }
                  className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                    task.completed
                      ? "bg-emerald-500 border-emerald-500"
                      : "border-white/20 hover:border-indigo-400"
                  }`}
                >
                  {task.completed && (
                    <CheckSquare className="w-4 h-4 text-white" />
                  )}
                </button>
                <span
                  className={`flex-1 text-sm font-mono ${task.completed ? "line-through text-white/40" : "text-white/90"}`}
                >
                  {task.text}
                </span>
                <button
                  onClick={() =>
                    user &&
                    deleteDoc(doc(db, "users", user.uid, "tasks", task.id))
                  }
                  className="opacity-0 group-hover:opacity-100 p-2 text-rose-400 hover:text-rose-300 transition-opacity"
                >
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    );
  };
  const handleSignIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Sign in error:", error);
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
  };

  const handlePuterSignIn = async () => {
    try {
      const u = await puter.auth.signIn();
      setPuterUser(u);
    } catch (error) {
      console.error("Puter sign in error:", error);
    }
  };

  const handlePuterSignOut = () => {
    puter.auth.signOut();
    setPuterUser(null);
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !user || isSending) return;

    const text = chatInput;
    setChatInput("");
    setIsSending(true);

    try {
      // 1. Add user message to Firestore
      await addDoc(collection(db, "users", user.uid, "chat"), {
        userId: user.uid,
        text,
        sender: "user",
        timestamp: serverTimestamp(),
        isSearch: useSearch,
      });

      // 2. Call Gemini
      let aiText = "";
      try {
        const res = await fetch("/api/ai/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text, useSearch }),
        });
        if (res.ok) {
          const data = await res.json();
          aiText =
            data.text ||
            "I was unable to process that signal. Neural drift detected.";
        } else {
          throw new Error("Failed to fetch from the Oracle");
        }
      } catch (err) {
        console.warn("Vertex failed, falling back to Puter AI", err);
        try {
          // Fallback to Puter AI
          const puterRes = await puter.ai.chat(
            `You are the AI Sports Betting Oracle. Responding to: ${text}`,
          );
          aiText =
            typeof puterRes?.message?.content === "string"
              ? puterRes.message.content
              : typeof puterRes === "string"
                ? puterRes
                : "Puter AI: Analysis complete.";
        } catch (puterErr) {
          console.error("Both Vertex and Puter failed", puterErr);
          aiText = "SYSTEM FAILURE: Neural links offline including Puter.";
        }
      }

      if (voiceEnabled) voiceService.speak(aiText);

      // 3. Add AI message to Firestore
      await addDoc(collection(db, "users", user.uid, "chat"), {
        userId: user.uid,
        text: aiText,
        sender: "ai",
        timestamp: serverTimestamp(),
      });
    } catch (error) {
      console.error("Chat error:", error);
      handleFirestoreError(error, "write", `users/${user.uid}/chat`);
    } finally {
      setIsSending(false);
    }
  };

  const generateAiFuture = async () => {
    setIsAiLoading(true);
    try {
      const res = await fetch("/api/ai/future", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents:
            "Provide a quick, punchy 3-bullet point 'Future Outlook' for a 'New Era' of AI sports betting starting today. Focus on how AI is revolutionizing accuracy and detecting institutional drift. Keep it professional, visionary, and concise. Use emojis.",
        }),
      });
      if (!res.ok) throw new Error("Failed to fetch from Vertex");
      const data = await res.json();
      setAiInsights(data.text || "The dawn of predictive clarity has arrived.");
    } catch (error) {
      console.warn("Vertex AI Error, resolving with Puter:", error);
      try {
        const puterRes = await puter.ai.chat(
          "Provide a quick, punchy 3-bullet point 'Future Outlook' for a 'New Era' of AI sports betting starting today. Give short concise bullet points.",
        );
        // Handling possibly different formats of response from puter
        const textRes =
          puterRes?.message?.content ||
          (typeof puterRes === "string"
            ? puterRes
            : "The dawn of predictive clarity has arrived.");
        setAiInsights(textRes);
      } catch (puterErr) {
        console.error("Puter AI Error:", puterErr);
        setAiInsights(
          "AI Oracle temporarily offline. Connectivity issues detected in neural link.",
        );
      }
    } finally {
      setIsAiLoading(false);
    }
  };

  const filteredSignals = signals
    .filter((s) => {
      if (eliteOnly) {
        return s.confidence === "High" && s.modelProb >= 0.85;
      }
      if (sortBy === "elite") {
        return s.confidence === "High" && s.modelProb >= 0.85;
      }
      return true;
    })
    .filter(
      (s) =>
        selectedSport === "All" ||
        s.sport?.toLowerCase() === selectedSport.toLowerCase(),
    )
    .filter(
      (s) =>
        s.match.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.league.toLowerCase().includes(searchQuery.toLowerCase()),
    )
    .sort((a, b) => {
      if (sortBy === "edge") return b.edge - a.edge;
      if (sortBy === "odds" || sortBy === "elite") return b.odds - a.odds;
      if (sortBy === "prob") return b.modelProb - a.modelProb;
      return 0;
    });

  const filteredLiveMatches = liveMatches.filter(
    (m) =>
      selectedSport === "All" ||
      m.sport?.toLowerCase() === selectedSport.toLowerCase(),
  );

  const LoadingSkeleton = () => (
    <div className="space-y-4 animate-pulse">
      {[1, 2, 3].map((i) => (
        <div
          key={i}
          className="h-32 bg-white/5 border border-white/5 rounded-2xl"
        />
      ))}
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-white p-4 pb-24 lg:pb-8 lg:p-8 font-sans selection:bg-emerald-500/30">
      {/* Decorative grain/noise pattern overlay */}
      <div
        className="fixed inset-0 pointer-events-none opacity-[0.02] z-0"
        style={{
          backgroundImage:
            'url("https://grainy-gradients.vercel.app/noise.svg")',
        }}
      />

      {/* 1. AUTONOMOUS HEALING OVERLAY */}
      <AnimatePresence>
        {health?.circuitBreaker && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[9999] flex items-center justify-center p-6 text-center"
          >
            <div className="max-w-md w-full">
              <div className="relative w-24 h-24 mx-auto mb-8">
                <RefreshCcw className="w-24 h-24 text-emerald-500 animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                    className="w-4 h-4 bg-emerald-500 rounded-full shadow-[0_0_20px_#10b981]"
                  />
                </div>
              </div>
              <h2 className="text-3xl font-bold text-white mb-2 tracking-tighter">
                NEURAL RESYNC
              </h2>
              <p className="text-emerald-500/60 font-mono text-xs uppercase tracking-widest mb-6">
                Autonomous Self-Correction Protocol Active
              </p>

              <div className="space-y-2 mb-8">
                {health.activeDefenses?.map((def, idx) => (
                  <motion.div
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: idx * 0.1 }}
                    key={idx}
                    className="bg-emerald-500/5 border border-emerald-500/20 py-2 px-4 rounded text-[10px] text-emerald-400 font-mono flex items-center justify-between"
                  >
                    <span>{def}</span>
                    <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                  </motion.div>
                ))}
              </div>
              <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 4 }}
                  className="h-full bg-emerald-500"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <header className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12 relative z-10">
        <div>
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-emerald-500 rounded-2xl shadow-[0_0_20px_rgba(16,185,129,0.4)]">
              <Target className="w-7 h-7 text-black" />
            </div>
            <div>
              <h1 className="text-4xl font-black tracking-tighter text-white uppercase italic">
                AI <span className="text-emerald-500 text-glow">BETTING</span>{" "}
                ENGINE
              </h1>
              <div className="flex items-center gap-2 mt-0.5">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                <p className="text-[10px] text-white/40 uppercase tracking-[0.2em] font-mono font-bold font-sans">
                  Value Detection • Real-time Alpha • v6.2.4
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 bg-white/5 border border-white/10 px-4 py-2 rounded-xl">
          {user ? (
            <div className="flex items-center gap-3">
              <div className="flex flex-col items-end">
                <span className="text-[10px] font-bold text-white/80">
                  {user.displayName}
                </span>
                <button
                  onClick={handleSignOut}
                  className="text-[8px] text-red-400 uppercase font-bold hover:underline"
                >
                  Log Out
                </button>
              </div>
              <img
                src={user.photoURL || ""}
                className="w-8 h-8 rounded-full border border-white/10"
                alt="profile"
              />
            </div>
          ) : (
            <button
              onClick={handleSignIn}
              className="flex items-center gap-2 px-4 py-2 bg-white text-black rounded-lg text-[10px] font-bold uppercase transition-all hover:bg-white/90"
            >
              <UserIcon className="w-3 h-3" /> Sign In
            </button>
          )}

          {puterUser ? (
            <div className="flex items-center gap-3 pl-2 border-l border-white/10">
              <div className="flex flex-col items-end">
                <span className="text-[10px] font-bold text-[#A78BFA]">
                  {puterUser.username}
                </span>
                <button
                  onClick={handlePuterSignOut}
                  className="text-[8px] text-red-400 uppercase font-bold hover:underline"
                >
                  Puter Out
                </button>
              </div>
              <div className="w-8 h-8 rounded-full bg-[#A78BFA] text-black flex items-center justify-center font-bold text-xs">
                {puterUser.username.substring(0, 1).toUpperCase()}
              </div>
            </div>
          ) : (
            <button
              onClick={handlePuterSignIn}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg text-[10px] font-bold uppercase transition-all hover:opacity-90 ml-2"
            >
              <Database className="w-3 h-3" /> Puter
            </button>
          )}

          <div className="h-8 w-px bg-white/10 mx-2" />
          <button
            onClick={() => setShowSettings(true)}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors group relative"
          >
            <Filter className="w-4 h-4 text-white/40 group-hover:text-emerald-400" />
            {health?.connectivity?.google_client === "PENDING_SETUP" && (
              <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-orange-500 rounded-full animate-pulse" />
            )}
          </button>
          <div className="h-4 w-px bg-white/10" />
          <div className="group relative">
            <div className="text-right cursor-help">
              <div className="text-[10px] text-white/30 uppercase tracking-widest font-mono">
                System Health
              </div>
              <div
                className={`text-xs font-bold flex items-center gap-2 justify-end ${loading ? "text-orange-400" : "text-emerald-400"}`}
              >
                {loading ? "SYNCING..." : "OPERATIONAL"}
                <div
                  className={`w-1.5 h-1.5 rounded-full ${loading ? "bg-orange-400 animate-pulse" : "bg-emerald-400"}`}
                />
              </div>
            </div>

            {/* Diagnostics Tooltip */}
            <div className="absolute top-full right-0 mt-2 w-64 bg-[#0F0F11] border border-white/10 rounded-2xl p-4 shadow-2xl opacity-0 translate-y-2 pointer-events-none group-hover:opacity-100 group-hover:translate-y-0 group-hover:pointer-events-auto transition-all z-50">
              <h4 className="text-[10px] font-bold uppercase tracking-widest text-white/40 mb-3 pb-2 border-b border-white/5">
                Google API Connectivity
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-white/60">Gemini Neural Link</span>
                  <span
                    className={
                      health?.connectivity?.gemini === "CONNECTED"
                        ? "text-emerald-400"
                        : "text-red-400"
                    }
                  >
                    {health?.connectivity?.gemini || "FETCHING..."}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-white/60">Search Grounding</span>
                  <span className="text-emerald-400">ACTIVE</span>
                </div>
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-white/60">Firebase Auth</span>
                  <span
                    className={user ? "text-emerald-400" : "text-orange-400"}
                  >
                    {user ? "AUTHENTICATED" : "WAITING"}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-white/60">Workspace Client</span>
                  <span
                    className={
                      health?.connectivity?.google_client === "CONFIGURED"
                        ? "text-emerald-400"
                        : "text-white/20"
                    }
                  >
                    {health?.connectivity?.google_client || "UNKNOWN"}
                  </span>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-white/5 text-[8px] font-mono text-white/20 uppercase">
                Engine: {health?.engine || "v5.2"} • Sync v5.2a
              </div>
            </div>
          </div>
          <div className="h-8 w-px bg-white/10 mx-2" />
          <button
            onClick={() => {
              fetchEngineData();
              fetchOdds(true);
              addNotification("Full System Refresh Initiated", "alert");
            }}
            className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl transition-colors font-bold text-xs uppercase"
          >
            <RefreshCcw
              className={`w-4 h-4 ${loading ? "animate-spin" : ""}`}
            />
            <span className="hidden md:inline">Refresh Data</span>
          </button>
        </div>
      </header>

      {/* 2. SYSTEM NERVOUS SYSTEM (TOP STATS) */}
      {!health?.circuitBreaker && (
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/5 border border-white/10 p-4 rounded-xl"
          >
            <div className="flex items-center gap-2 mb-1 text-white/40 uppercase text-[9px] font-bold tracking-widest font-mono">
              <ShieldCheck className="w-3 h-3 text-emerald-500" /> System
              Integrity
            </div>
            <div className="flex items-end justify-between">
              <span className="text-xl font-bold text-white uppercase">
                {health?.errorCount === 0
                  ? "Optimal"
                  : `Stable (${health?.errorCount} err)`}
              </span>
              <span className="text-[10px] text-emerald-500 font-mono">
                Uptime: {Math.floor(health?.uptime || 0)}s
              </span>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/5 border border-white/10 p-4 rounded-xl"
          >
            <div className="flex items-center gap-2 mb-1 text-white/40 uppercase text-[9px] font-bold tracking-widest font-mono">
              <Cpu className="w-3 h-3 text-emerald-500" /> Data Absorption
            </div>
            <div className="flex items-end justify-between">
              <span className="text-xl font-bold text-white uppercase">
                {metrics?.neuralAmmunition?.dynamic || "0.00"} MB
              </span>
              <span className="text-[10px] text-emerald-500 font-mono">
                Live Stream Active
              </span>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/5 border border-white/10 p-4 rounded-xl"
          >
            <div className="flex items-center gap-2 mb-1 text-white/40 uppercase text-[9px] font-bold tracking-widest font-mono">
              <Zap className="w-3 h-3 text-emerald-500" /> Self-Corrections
            </div>
            <div className="flex items-end justify-between">
              <span className="text-xl font-bold text-white uppercase">
                {evolutionStats?.activeSelfCorrections || "0"}
              </span>
              <span className="text-[10px] text-emerald-500 font-mono">
                Autonomous Opt.
              </span>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white/5 border border-white/10 p-4 rounded-xl"
          >
            <div className="flex items-center gap-2 mb-1 text-white/40 uppercase text-[9px) font-bold tracking-widest font-mono">
              <Activity className="w-3 h-3 text-emerald-500" /> Pulse Frequency
            </div>
            <div className="flex items-end justify-between text-white uppercase">
              <span className="text-xl font-bold">144.2 Hz</span>
              <motion.div
                animate={{ scale: [1, 1.4, 1], opacity: [0.4, 1, 0.4] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
                className="w-2 h-2 bg-emerald-500 rounded-full"
              />
            </div>
          </motion.div>
        </div>
      )}

      {/* Tabs Navigation */}
      <div className="max-w-7xl mx-auto flex overflow-x-auto hide-scrollbar gap-4 mb-8 pb-2 snap-x">
        <button
          onClick={() => setActiveTab("elite")}
          className={`flex-none snap-start px-6 py-2 rounded-xl text-xs font-bold tracking-widest transition-all ${
            activeTab === "elite"
              ? "bg-emerald-500 text-black shadow-[0_0_20px_rgba(16,185,129,0.3)]"
              : "bg-white/10 text-white/80 hover:text-white"
          }`}
        >
          ELITE ANALYST
        </button>
        <button
          onClick={() => setActiveTab("signals")}
          className={`flex-none snap-start px-6 py-2 rounded-xl text-xs font-bold tracking-widest transition-all ${
            activeTab === "signals"
              ? "bg-emerald-500 text-black"
              : "bg-white/5 text-white/40 hover:text-white"
          }`}
        >
          ALPHA SIGNALS
        </button>
        <button
          onClick={() => setActiveTab("metrics")}
          className={`flex-none snap-start px-6 py-2 rounded-xl text-xs font-bold tracking-widest transition-all ${
            activeTab === "metrics"
              ? "bg-emerald-500 text-black"
              : "bg-white/5 text-white/40 hover:text-white"
          }`}
        >
          MODEL METRICS
        </button>
        <button
          onClick={() => setActiveTab("evolution")}
          className={`flex-none snap-start px-6 py-2 rounded-xl text-xs font-bold tracking-widest transition-all ${
            activeTab === "evolution"
              ? "bg-orange-500 text-white shadow-[0_0_20px_rgba(249,115,22,0.3)]"
              : "bg-white/5 text-white/40 hover:text-white"
          }`}
        >
          SINGULARITY CORE
        </button>
        <button
          onClick={() => setActiveTab("tasks")}
          className={`flex-none snap-start px-6 py-2 rounded-xl text-xs font-bold tracking-widest transition-all ${
            activeTab === "tasks"
              ? "bg-indigo-500 text-white shadow-[0_0_20px_rgba(79,70,229,0.3)]"
              : "bg-white/5 text-white/40 hover:text-white"
          }`}
        >
          RESEARCH QUESTS
        </button>
        <button
          onClick={() => setActiveTab("taxes")}
          className={`flex-none snap-start px-6 py-2 rounded-xl text-xs font-bold tracking-widest transition-all ${
            activeTab === "taxes"
              ? "bg-emerald-500 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)]"
              : "bg-white/5 text-white/40 hover:text-white"
          }`}
        >
          TAX ENGINE
        </button>
        <button
          onClick={() => setActiveTab("accumulators")}
          className={`flex-none snap-start px-6 py-2 rounded-xl text-xs font-bold tracking-widest transition-all ${
            activeTab === "accumulators"
              ? "bg-indigo-500 text-white shadow-[0_0_20px_rgba(79,70,229,0.3)]"
              : "bg-white/5 text-white/40 hover:text-white"
          }`}
        >
          SAFE PEAK ACCUMULATORS
        </button>
        <button
          onClick={() => setActiveTab("live")}
          className={`flex-none snap-start px-6 py-2 rounded-xl text-xs font-bold tracking-widest transition-all ${
            activeTab === "live"
              ? "bg-red-500 text-white shadow-[0_0_20px_rgba(239,68,68,0.3)]"
              : "bg-white/5 text-white/40 hover:text-white"
          }`}
        >
          LIVE SCORES & PREDICTIONS
        </button>
        <button
          onClick={() => setActiveTab("futures")}
          className={`flex-none snap-start px-6 py-2 rounded-xl text-xs font-bold tracking-widest transition-all ${
            activeTab === "futures"
              ? "bg-amber-500 text-white shadow-[0_0_20px_rgba(245,158,11,0.3)]"
              : "bg-white/5 text-white/40 hover:text-white"
          }`}
        >
          AI FUTURES
        </button>
        <button
          onClick={() => setActiveTab("logs")}
          className={`flex-none snap-start px-6 py-2 rounded-xl text-xs font-bold tracking-widest transition-all ${
            activeTab === "logs"
              ? "bg-zinc-500 text-white shadow-[0_0_20px_rgba(113,113,122,0.3)]"
              : "bg-white/5 text-white/40 hover:text-white"
          }`}
        >
          SYSTEM LOGS
        </button>
      </div>

      {/* Main Grid */}
      <div className="max-w-7xl mx-auto grid grid-cols-12 gap-8">
        {/* Left Column: Signals List / Metrics */}
        <div className="col-span-12 lg:col-span-8 space-y-6">
          {activeTab === "elite" && renderEliteAnalyst()}
          {activeTab === "tasks" && renderTaskList()}
          {activeTab === "taxes" && renderTaxManagement()}

          {activeTab === "logs" && (
            <div className="space-y-6 animate-in fade-in duration-500">
              <div className="p-6 bg-[#0F0F11] rounded-3xl border border-white/5 relative overflow-hidden group">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold tracking-tighter text-white">
                    SYSTEM ALERT LOG
                  </h2>
                  <div className="px-3 py-1 bg-white/5 rounded-full text-[10px] font-bold text-white/40 uppercase tracking-widest border border-white/5">
                    Monitoring Core
                  </div>
                </div>
                <div className="space-y-3">
                  {evolutionLogs.slice(0, 15).map((log, i) => (
                    <div
                      key={i}
                      className="flex gap-4 p-4 border border-white/5 rounded-2xl bg-white/5 items-start"
                    >
                      <div
                        className={`w-2 h-2 rounded-full mt-1.5 shrink-0 animate-pulse ${log.type === "ALERT" || log.type === "HEAL" || log.type === "ERROR" ? "bg-red-500" : "bg-orange-500"}`}
                      />
                      <div>
                        <p className="text-[10px] text-white/40 font-mono mb-1">
                          {new Date(log.timestamp).toLocaleTimeString()} •{" "}
                          {log.type}
                        </p>
                        <p className="text-sm text-white/80">{log.message}</p>
                      </div>
                    </div>
                  ))}
                  {evolutionLogs.length === 0 && (
                    <div className="p-8 text-center text-white/40 text-sm font-mono border border-white/5 rounded-2xl border-dashed">
                      No alerts recorded in the current session.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === "evolution" && (
            <div className="space-y-8 animate-in fade-in duration-500">
              {/* Singularity Header */}
              <div className="relative p-12 bg-gradient-to-br from-orange-500/20 via-black to-black rounded-[3rem] border border-orange-500/20 overflow-hidden group">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20" />
                <div className="absolute top-0 right-0 w-96 h-96 bg-orange-600/10 rounded-full blur-[120px] -mr-32 -mt-32 animate-pulse" />

                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="p-4 bg-orange-500/20 rounded-3xl border border-orange-500/30">
                      <Infinity className="w-10 h-10 text-orange-500" />
                    </div>
                    <div>
                      <h2 className="text-4xl font-black tracking-tighter text-white">
                        SINGULARITY CORE
                      </h2>
                      <p className="text-xs font-mono text-orange-500/60 uppercase tracking-[0.2em]">
                        Autonomous Self-Evolution Engine v1.0 • Experimental
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-10">
                    <div className="bg-black/40 backdrop-blur-xl p-6 rounded-3xl border border-white/5">
                      <div className="text-[10px] text-white/40 uppercase font-black mb-1">
                        Neural Growth
                      </div>
                      <div className="text-3xl font-mono font-bold text-orange-500">
                        {(evolutionStats?.neuralGrowth || 0) * 100}%
                      </div>
                      <div className="w-full h-1 bg-white/5 rounded-full mt-3">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: "84%" }}
                          className="h-full bg-orange-500"
                        />
                      </div>
                    </div>
                    <div className="bg-black/40 backdrop-blur-xl p-6 rounded-3xl border border-white/5">
                      <div className="text-[10px] text-white/40 uppercase font-black mb-1">
                        Self-Corrections
                      </div>
                      <div className="text-3xl font-mono font-bold text-white">
                        {evolutionStats?.activeSelfCorrections || 0}
                      </div>
                      <div className="text-[8px] text-emerald-400 font-mono mt-2 flex items-center gap-1">
                        <TrendingUp className="w-2 h-2" /> 12 since last cycle
                      </div>
                    </div>
                    <div className="bg-black/40 backdrop-blur-xl p-6 rounded-3xl border border-white/5 relative overflow-hidden">
                      <div className="absolute inset-0 bg-blue-500/5 animate-pulse pointer-events-none" />
                      <div className="text-[10px] text-white/40 uppercase font-black mb-1">
                        Neural Latency
                      </div>
                      <div className="text-3xl font-mono font-bold text-blue-400">
                        14ms
                      </div>
                      <div className="text-[8px] text-white/20 font-mono mt-2 uppercase">
                        Quantum Sync: Locked
                      </div>
                    </div>
                    <div className="bg-black/40 backdrop-blur-xl p-6 rounded-3xl border border-white/5">
                      <div className="text-[10px] text-white/40 uppercase font-black mb-1">
                        Upgrades Generated
                      </div>
                      <div className="text-3xl font-mono font-bold text-white">
                        {evolutionStats?.totalUpgradesGenerated || 0}
                      </div>
                      <div className="text-[8px] text-white/20 font-mono mt-2">
                        v5.2 is 92% AI-Code
                      </div>
                    </div>
                    <div className="bg-black/40 backdrop-blur-xl p-6 rounded-3xl border border-white/5">
                      <div className="text-[10px] text-white/40 uppercase font-black mb-1">
                        Next Evolution
                      </div>
                      <div className="text-sm font-mono font-bold text-white">
                        {evolutionStats
                          ? new Date(
                              evolutionStats.nextImprovementCycle,
                            ).toLocaleDateString()
                          : "N/A"}
                      </div>
                      <div className="text-[8px] text-orange-500/60 font-mono mt-2 uppercase">
                        Scheduled Rebuild
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={triggerEvolutionScan}
                    disabled={isAnalyzingEvolution}
                    className="group relative px-10 py-5 bg-white text-black rounded-3xl font-black uppercase tracking-widest text-sm overflow-hidden transition-all hover:scale-105 active:scale-95 disabled:opacity-50"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-red-500 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                    <span className="relative z-10 flex items-center gap-3">
                      <Cpu
                        className={`w-5 h-5 ${isAnalyzingEvolution ? "animate-spin" : ""}`}
                      />
                      {isAnalyzingEvolution
                        ? "ANALYZING NEURAL ARCHITECTURE..."
                        : "TRIGGER EVOLUTION SCAN"}
                    </span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Predictive Error Correction */}
                <div className="space-y-6">
                  <h3 className="text-sm font-black uppercase tracking-widest flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-orange-500" />{" "}
                    Predictive Error Correction
                  </h3>
                  <div className="space-y-4">
                    {predictedErrors.map((error, idx) => (
                      <div
                        key={idx}
                        className="p-6 bg-white/5 rounded-[2rem] border border-white/10 flex items-start gap-6 hover:bg-white/10 transition-colors"
                      >
                        <div
                          className={`p-4 rounded-2xl ${error.risk === "High" ? "bg-red-500/20 text-red-500" : "bg-orange-500/20 text-orange-500 border border-orange-500/20"}`}
                        >
                          <AlertCircle className="w-6 h-6" />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-[10px] font-bold text-white/40 uppercase">
                              {error.component}
                            </span>
                            <span className="text-[10px] font-mono text-orange-500">
                              T-MINUS {error.timeToIncident}
                            </span>
                          </div>
                          <h4 className="text-lg font-bold text-white mb-2">
                            {error.predictedError}
                          </h4>
                          <div className="flex items-center gap-3">
                            <div className="text-[9px] px-3 py-1 bg-white/5 rounded-full border border-white/5 text-white/60 font-mono">
                              STRATEGY: {error.correctionStrategy}
                            </div>
                            <div className="text-[8px] text-emerald-400 uppercase font-black tracking-widest">
                              Auto-Correction Armed
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Evolution History */}
                <div className="space-y-6">
                  <h3 className="text-sm font-black uppercase tracking-widest flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-white/40" /> Evolution
                    Logs
                  </h3>
                  <div className="bg-[#0A0A0B] p-6 rounded-[2rem] border border-white/5 font-mono text-[10px] space-y-4 h-[400px] overflow-y-auto custom-scrollbar">
                    {evolutionLogs.map((log) => (
                      <div key={log.id} className="flex gap-4 group">
                        <span className="text-white/20 whitespace-nowrap">
                          [{new Date(log.timestamp).toLocaleTimeString()}]
                        </span>
                        <span
                          className={`font-black ${
                            log.type === "HEALING"
                              ? "text-emerald-400"
                              : log.type === "UPGRADE"
                                ? "text-blue-400"
                                : "text-orange-400"
                          }`}
                        >
                          [{log.type}]
                        </span>
                        <span className="text-white/60 group-hover:text-white transition-colors">
                          {log.message}
                        </span>
                      </div>
                    ))}
                    <div className="flex gap-4">
                      <span className="text-white/20">[SYSTEM]</span>
                      <span className="text-orange-500 animate-pulse">_</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "futures" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-5 duration-500">
              <div className="relative p-12 bg-gradient-to-br from-amber-500/20 via-black to-black rounded-[3rem] border border-amber-500/20 overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20" />
                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-4 bg-amber-500 rounded-3xl">
                      <Telescope className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <h2 className="text-4xl font-black tracking-tighter text-white">
                        PERMANENT ORACLE
                      </h2>
                      <p className="text-xs font-mono text-amber-500/60 uppercase tracking-widest">
                        Continuous Match Futurity Engine
                      </p>
                    </div>
                  </div>
                  <p className="text-white/60 max-w-2xl text-sm leading-relaxed">
                    The Permanent Oracle runs millions of parallel simulations
                    to predict exact match outcomes for today, tomorrow, and the
                    upcoming weekends. It evaluates teams, probabilities, and
                    provides the best recommendation bets across all markets
                    permanently.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {futures.map((fut) => (
                  <div
                    key={fut.id}
                    onClick={() =>
                      setExpandedMatch({ ...fut, market: fut.projection })
                    }
                    className="cursor-pointer group relative bg-[#0F0F11] rounded-[2.5rem] border border-white/5 overflow-hidden hover:border-amber-500/30 transition-all"
                  >
                    <div className="p-8">
                      <div className="flex justify-between items-start mb-6">
                        <div>
                          <div className="text-[10px] font-black text-amber-500 uppercase tracking-widest mb-1">
                            {fut.title}
                          </div>
                          <h3 className="text-2xl font-black text-white tracking-tighter">
                            {fut.projection}
                          </h3>
                        </div>
                        <div className="px-4 py-2 bg-amber-500/10 rounded-2xl border border-amber-500/20 text-center">
                          <div className="text-[9px] font-bold text-amber-500 uppercase">
                            Probability
                          </div>
                          <div className="text-lg font-mono font-bold text-white">
                            {(fut.prob * 100).toFixed(0)}%
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 mb-6">
                        <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                          <div className="text-[8px] text-white/40 uppercase mb-1">
                            Temporal Confidence
                          </div>
                          <div className="text-xs font-bold text-white">
                            {fut.temporalConfidence}
                          </div>
                        </div>
                        <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                          <div className="text-[8px] text-white/40 uppercase mb-1">
                            Simulations
                          </div>
                          <div className="text-xs font-bold text-white">
                            {fut.simulations}
                          </div>
                        </div>
                        <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                          <div className="text-[8px] text-white/40 uppercase mb-1">
                            Risk Factor
                          </div>
                          <div
                            className={`text-xs font-bold ${
                              fut.riskFactor === "Extreme"
                                ? "text-red-500"
                                : fut.riskFactor === "High"
                                  ? "text-orange-500"
                                  : "text-emerald-500"
                            }`}
                          >
                            {fut.riskFactor}
                          </div>
                        </div>
                      </div>

                      <div className="bg-black/40 p-4 rounded-2xl border border-white/5 mb-6">
                        <div className="text-[9px] font-black text-white/20 uppercase tracking-widest mb-2 flex items-center gap-2">
                          <Cpu className="w-3 h-3" /> Oracle Narrative
                        </div>
                        <p className="text-[10px] text-white/60 leading-relaxed italic font-mono">
                          "{fut.narrative}"
                        </p>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                          <span className="text-[8px] text-white/40 uppercase font-black">
                            Simulation Active
                          </span>
                        </div>
                        <div
                          className={`text-[8px] font-black uppercase px-3 py-1 rounded-full ${
                            fut.impact === "Legendary"
                              ? "bg-purple-500/20 text-purple-400"
                              : fut.impact === "Critical"
                                ? "bg-red-500/20 text-red-500"
                                : "bg-white/10 text-white/40"
                          }`}
                        >
                          IMPACT: {fut.impact}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "live" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-5 duration-500">
              <div className="relative p-12 bg-gradient-to-br from-red-500/20 via-black to-black rounded-[3rem] border border-red-500/20 overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20" />
                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="p-4 bg-red-500 rounded-3xl animate-pulse">
                        <Radio className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h2 className="text-4xl font-black tracking-tighter text-white uppercase italic">
                          Live Neural Feed
                        </h2>
                        <p className="text-xs font-mono text-red-400 uppercase tracking-widest">
                          In-Game Probability Analysis
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex-none">
                    <select
                      value={selectedSport}
                      onChange={(e) => setSelectedSport(e.target.value)}
                      className="bg-black/50 border border-red-500/20 text-white rounded-xl py-3 px-4 text-sm font-bold uppercase tracking-widest focus:outline-none focus:border-red-500/50 appearance-none w-48 text-center"
                    >
                      <option value="All">All Sports</option>
                      <option value="Football">Football</option>
                      <option value="Basketball">Basketball</option>
                      <option value="Tennis">Tennis</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-8">
                {filteredLiveMatches.map((match) => (
                  <div
                    key={match.id}
                    onClick={() => setExpandedMatch(match)}
                    className="cursor-pointer hover:border-red-500/50 transition-all bg-white/5 rounded-[2.5rem] border border-white/10 overflow-hidden"
                  >
                    <div className="p-8">
                      <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-8 border-b border-white/5 pb-8">
                        <div className="text-center md:text-left">
                          <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
                            <div className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em]">
                              {match.sport ? `${match.sport} • ` : ""}
                              {match.league}
                            </div>
                            {match.realTime && (
                              <div className="flex items-center gap-1 bg-red-500/10 px-2 py-0.5 rounded border border-red-500/20">
                                <div className="w-1 h-1 bg-red-500 rounded-full animate-pulse" />
                                <span className="text-[8px] font-bold text-red-500">
                                  LIVE
                                </span>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-8">
                            <div className="text-center">
                              <h4 className="text-xl font-bold text-white">
                                {match.homeTeam}
                              </h4>
                              <div className="text-4xl font-black text-white mt-2">
                                {match.homeScore}
                              </div>
                            </div>
                            <div className="text-red-500 font-mono font-bold text-xl animate-pulse">
                              VS
                            </div>
                            <div className="text-center">
                              <h4 className="text-xl font-bold text-white">
                                {match.awayTeam}
                              </h4>
                              <div className="text-4xl font-black text-white mt-2">
                                {match.awayScore}
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="bg-white/5 p-6 rounded-3xl border border-white/5 min-w-[200px]">
                          <div className="flex items-center gap-2 mb-4">
                            <Timer className="w-4 h-4 text-red-500" />
                            <span className="text-xl font-mono font-bold text-white italic">
                              {match.time}
                            </span>
                          </div>
                          <div className="space-y-4">
                            {/* Possession Bar */}
                            <div>
                              <div className="flex justify-between text-[8px] font-black text-white/40 uppercase tracking-tighter mb-1">
                                <span>Possession</span>
                                <span>
                                  {match.stats.possession}% -{" "}
                                  {100 - match.stats.possession}%
                                </span>
                              </div>
                              <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden flex">
                                <motion.div
                                  className="h-full bg-red-500"
                                  initial={{ width: 0 }}
                                  animate={{
                                    width: `${match.stats.possession}%`,
                                  }}
                                  transition={{ type: "spring", stiffness: 50 }}
                                />
                                <div className="flex-1 bg-white/10" />
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-2">
                              <div className="p-2 bg-white/5 rounded-xl border border-white/5 text-center">
                                <div className="text-[7px] font-black text-white/20 uppercase tracking-tighter mb-1">
                                  Corners
                                </div>
                                <div className="text-xs font-mono font-bold text-white">
                                  {match.stats.corners.home} -{" "}
                                  {match.stats.corners.away}
                                </div>
                              </div>
                              <div className="p-2 bg-white/5 rounded-xl border border-white/5 text-center">
                                <div className="text-[7px] font-black text-white/20 uppercase tracking-tighter mb-1">
                                  S.O.T
                                </div>
                                <div className="text-xs font-mono font-bold text-white">
                                  {match.stats.shotsOnTarget.home} -{" "}
                                  {match.stats.shotsOnTarget.away}
                                </div>
                              </div>
                              <div className="p-2 bg-white/5 rounded-xl border border-white/5 text-center">
                                <div className="text-[7px] font-black text-white/20 uppercase tracking-tighter mb-1">
                                  Cards
                                </div>
                                <div className="text-xs font-mono font-bold text-yellow-500">
                                  {match.stats.cards.home} -{" "}
                                  {match.stats.cards.away}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {match.inGamePredictions.map((pred, i) => (
                          <div
                            key={i}
                            className="p-5 bg-black/40 rounded-3xl border border-white/5 hover:border-red-500/30 transition-all"
                          >
                            <div className="text-[9px] font-black text-white/40 uppercase tracking-widest mb-1">
                              {pred.market}
                            </div>
                            <div className="text-sm font-bold text-white mb-1">
                              {pred.prediction}
                            </div>
                            <div className="text-[7px] text-white/20 uppercase font-black tracking-widest mb-2">
                              Feed: {pred.bookmaker || "1xBet"}
                            </div>
                            <div className="flex justify-between items-end">
                              <div>
                                <div className="text-[10px] font-mono text-emerald-400">
                                  {(pred.prob * 100).toFixed(0)}% PROB
                                </div>
                                <div
                                  className={`text-[8px] font-bold uppercase mt-1 ${pred.prob > 0.75 ? "text-emerald-500" : pred.prob > 0.5 ? "text-orange-500" : "text-red-500"}`}
                                >
                                  CONF:{" "}
                                  {pred.prob > 0.75
                                    ? "HIGH"
                                    : pred.prob > 0.5
                                      ? "MED"
                                      : "LOW"}
                                </div>
                              </div>
                              <motion.div
                                key={pred.odds}
                                initial={{ scale: 1.2, color: "#ef4444" }}
                                animate={{ scale: 1, color: "#ffffff" }}
                                className="text-lg font-mono font-bold"
                              >
                                {pred.odds.toFixed(2)}
                              </motion.div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* REAL TIME ODDS SECTION */}
              <div className="mt-12 bg-white/5 p-8 rounded-[3rem] border border-white/10">
                <div className="flex flex-col md:flex-row items-center gap-4 mb-8">
                  <Database className="w-6 h-6 text-emerald-500" />
                  <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter">
                    Real-Time Odds Feed{" "}
                    <span className="text-[10px] text-emerald-500 font-mono align-top ml-2">
                      THE ODDS API
                    </span>
                  </h3>

                  <div className="flex items-center gap-4 ml-auto w-full md:w-auto">
                    <input
                      type="text"
                      placeholder="Filter Odds..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="bg-black/50 border border-white/10 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500/50 w-full md:w-48"
                    />
                    <button
                      onClick={() => {
                        addNotification("Refreshing odds feed...", "alert");
                        fetchOdds(true).then(() =>
                          addNotification(
                            "Odds feed updated successfully.",
                            "success",
                          ),
                        );
                      }}
                      className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-500 text-xs font-mono rounded-xl transition-all whitespace-nowrap"
                    >
                      <RefreshCcw
                        className={`w-4 h-4 ${isFetchingOdds ? "animate-spin" : ""}`}
                      />
                      {isFetchingOdds ? "FETCHING" : "REFRESH"}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {realTimeOdds.length === 0 && !isFetchingOdds ? (
                    <div className="col-span-full py-8 text-center text-white/30 text-sm font-mono uppercase tracking-widest">
                      NO DATA AVAILABLE. CHECK API KEY IN .ENV.
                    </div>
                  ) : (
                    realTimeOdds
                      .filter(
                        (odds) =>
                          odds.home_team
                            .toLowerCase()
                            .includes(searchQuery.toLowerCase()) ||
                          odds.away_team
                            .toLowerCase()
                            .includes(searchQuery.toLowerCase()) ||
                          odds.sport_title
                            .toLowerCase()
                            .includes(searchQuery.toLowerCase()),
                      )
                      .map((odds: any) => {
                        const bookmaker = odds.bookmakers?.[0];
                        const market = bookmaker?.markets?.[0];
                        const outcomes = market?.outcomes || [];
                        return (
                          <div
                            key={odds.id}
                            className="p-6 bg-black/40 rounded-2xl border border-white/5 hover:border-emerald-500/30 transition-all"
                          >
                            <div className="text-[10px] text-emerald-500/50 uppercase tracking-widest mb-1">
                              {odds.sport_title}
                            </div>
                            <div className="font-bold text-white mb-4">
                              {odds.home_team} vs {odds.away_team}
                            </div>
                            <div className="text-[9px] text-white/40 uppercase tracking-widest mb-2 font-black">
                              Feed: {bookmaker?.title || "Unknown"} •{" "}
                              {market?.key || "h2h"}
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {outcomes.map((outcome: any, idx: number) => (
                                <div
                                  key={idx}
                                  className="flex-1 bg-white/5 p-3 rounded-xl border border-white/5 text-center"
                                >
                                  <div className="text-[10px] text-white/60 mb-1">
                                    {outcome.name}
                                  </div>
                                  <DynamicOdd price={outcome.price} />
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === "accumulators" && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-5 duration-500">
              <div className="relative p-12 bg-gradient-to-br from-indigo-500/20 via-black to-black rounded-[3rem] border border-indigo-500/20 overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20" />
                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="p-4 bg-indigo-500 rounded-3xl">
                        <ShieldCheck className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h2 className="text-4xl font-black tracking-tighter text-white">
                          SAFE PEAK
                        </h2>
                        <p className="text-xs font-mono text-indigo-400 uppercase tracking-widest">
                          Rigid & Verified Accumulators
                        </p>
                      </div>
                    </div>
                    <p className="text-white/60 max-w-xl text-sm leading-relaxed mb-6">
                      Our Safe Peak engine selects only the highest probability
                      events ({(bettingRules.minProbability * 100).toFixed(0)}
                      %+) to build daily accumulators. These are
                      cross-referenced with institutional flow to ensure minimum
                      variance and maximum reliability.
                    </p>
                    <div className="flex gap-4">
                      <div className="px-4 py-2 bg-white/5 rounded-full border border-white/10 text-[10px] font-bold text-white/60 uppercase tracking-widest">
                        Calculated Risk: LOW
                      </div>
                      <div className="px-4 py-2 bg-white/5 rounded-full border border-white/10 text-[10px] font-bold text-emerald-400 uppercase tracking-widest">
                        Verified Process ✅
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {accumulators.map((acc) => (
                  <div
                    key={acc.id}
                    className="bg-white/5 rounded-[2.5rem] border border-white/10 overflow-hidden group hover:border-indigo-500/30 transition-all"
                  >
                    <div className="p-8">
                      <div className="flex justify-between items-start mb-8">
                        <div>
                          <div className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">
                            {acc.type}
                          </div>
                          <h3 className="text-2xl font-black text-white tracking-tighter">
                            {acc.name}
                          </h3>
                        </div>
                        <div className="text-right">
                          <div className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-1">
                            Total Odds
                          </div>
                          <div className="text-3xl font-mono font-bold text-white tracking-tighter">
                            {acc.totalOdds}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4 mb-8">
                        {acc.selections.map((sel) => (
                          <div
                            key={sel.id}
                            onClick={() => setExpandedMatch(sel)}
                            className="cursor-pointer hover:bg-white/10 hover:border-emerald-500/50 transition-all flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5"
                          >
                            <div>
                              <div className="text-[10px] font-bold text-white/40 uppercase mb-1">
                                {sel.league}
                              </div>
                              <div className="text-sm font-bold text-white">
                                {sel.match}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-[10px] font-bold text-emerald-400/60 uppercase mb-1">
                                {(sel.prob * 100).toFixed(0)}% PROB
                              </div>
                              <div className="text-sm font-mono font-bold text-white">
                                {sel.odds}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="grid grid-cols-2 gap-4 mb-8">
                        <div className="p-4 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
                          <div className="text-[10px] font-bold text-indigo-400 uppercase mb-1">
                            Win Probability
                          </div>
                          <div className="text-xl font-mono font-bold text-white">
                            {(acc.combinedProb * 100).toFixed(1)}%
                          </div>
                        </div>
                        <div className="p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/20">
                          <div className="text-[10px] font-bold text-emerald-400 uppercase mb-1">
                            Status
                          </div>
                          <div className="text-xl font-bold text-white">
                            {acc.confidence}
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() =>
                          (decodingStatus[acc.id] || "idle") === "idle" &&
                          handleDecodeAcc(acc.id)
                        }
                        disabled={(decodingStatus[acc.id] || "idle") !== "idle"}
                        className={`w-full py-5 rounded-3xl font-black uppercase tracking-widest text-sm transition-all shadow-[0_10px_20px_rgba(255,255,255,0.1)] ${
                          (decodingStatus[acc.id] || "idle") === "decoded"
                            ? "bg-emerald-500 text-black border border-emerald-400"
                            : (decodingStatus[acc.id] || "idle") === "decoding"
                              ? "bg-indigo-500 text-white animate-pulse"
                              : "bg-white text-black hover:scale-[1.02] active:scale-[0.98]"
                        }`}
                      >
                        {(decodingStatus[acc.id] || "idle") === "decoded"
                          ? `BOOKING CODE: ${(Math.random() * 1000000).toString(16).substring(0, 6).toUpperCase()} ${"✅"}`
                          : (decodingStatus[acc.id] || "idle") === "decoding"
                            ? "QUANTUM DECRYPTION IN PROGRESS..."
                            : "DECODE ACCUMULATOR"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "signals" ? (
            <>
              {/* Global Search Integration */}
              <div className="bg-gradient-to-r from-emerald-500/10 to-transparent p-6 rounded-3xl border border-white/5 mb-8 flex flex-col md:flex-row items-center gap-6">
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                    <Globe className="w-5 h-5 text-emerald-400" /> Grounded
                    Intelligence
                  </h3>
                  <p className="text-xs text-white/40 font-mono">
                    Real-time search engine enabled. All predictions are
                    cross-referenced with live market drift and institutional
                    volume signals.
                  </p>
                </div>
                {metrics?.neuralAmmunition && (
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full border-2 border-dashed border-red-500/30 flex items-center justify-center relative">
                      <ShieldCheck className="w-5 h-5 text-red-500" />
                      <div className="absolute inset-0 bg-red-500/20 rounded-full blur-xl" />
                    </div>
                    <div>
                      <div className="text-[10px] font-bold text-white/40 uppercase">
                        Ammunition Reserve
                      </div>
                      <div className="text-sm font-mono text-white font-bold">
                        ${metrics.neuralAmmunition.reserve.toLocaleString()}
                      </div>
                    </div>
                  </div>
                )}
                <div className="flex items-center gap-2 bg-black/40 p-2 rounded-2xl border border-white/10">
                  <div
                    className={`p-2 rounded-lg ${useSearch ? "bg-emerald-500" : "bg-white/5"}`}
                  >
                    <Search
                      className={`w-4 h-4 ${useSearch ? "text-black" : "text-white/20"}`}
                    />
                  </div>
                  <button
                    onClick={() => setUseSearch(!useSearch)}
                    className="text-[10px] font-bold uppercase tracking-widest px-4 py-2 hover:bg-white/5 rounded-xl transition-all"
                  >
                    {useSearch ? "Search Engine ON" : "AI Offline Mode"}
                  </button>
                </div>
              </div>

              {/* Neural Routes Integration */}
              <div className="mb-12">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-sm font-bold uppercase tracking-widest flex items-center gap-2">
                    <Zap className="w-4 h-4 text-blue-500" /> Real-time Global
                    Routes
                  </h2>
                  <div className="flex gap-2">
                    {metrics?.dataRoutes?.map((route) => (
                      <div
                        key={route.id}
                        className="flex items-center gap-2 bg-white/5 px-3 py-1 rounded-full border border-white/10"
                      >
                        <span className="w-1 h-1 bg-blue-500 rounded-full animate-ping" />
                        <span className="text-[8px] font-mono text-white/60">
                          {route.id}
                        </span>
                        <span className="text-[8px] font-mono text-blue-400">
                          {route.latency}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {metrics?.dataRoutes?.map((route) => (
                    <div
                      key={route.id}
                      className="p-4 bg-white/5 rounded-2xl border border-white/5 hover:border-blue-500/30 transition-all group overflow-hidden relative"
                    >
                      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-blue-500/10 transition-colors" />
                      <div className="text-[10px] text-white/40 mb-1 uppercase font-mono">
                        {route.source}
                      </div>
                      <div className="flex items-end justify-between">
                        <div className="text-xl font-bold font-mono tracking-tighter">
                          INTEGRATED
                        </div>
                        <div className="text-[10px] font-bold text-blue-500">
                          {route.load}% LOAD
                        </div>
                      </div>
                      <div className="mt-3 h-1 bg-white/5 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${route.load}%` }}
                          className="h-full bg-blue-500"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 px-2 text-white">
                <h2 className="text-sm font-bold uppercase tracking-widest flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-500" /> Detected
                  Alpha Signals
                  <span className="text-[8px] px-2 py-1 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 rounded-md">
                    3D NEURAL EXPORT ACTIVE
                  </span>
                </h2>
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 w-full sm:w-auto">
                  <button
                    onClick={() => setEliteOnly(!eliteOnly)}
                    className={`px-3 py-2 border rounded-lg text-xs font-bold uppercase tracking-widest transition-all whitespace-nowrap ${eliteOnly ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/50" : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white"}`}
                  >
                    Alerts Filter: {eliteOnly ? "ON" : "OFF"}
                  </button>
                  <select
                    value={selectedSport}
                    onChange={(e) => setSelectedSport(e.target.value)}
                    className="bg-white/5 border border-white/10 rounded-lg py-2 px-3 text-xs focus:outline-none"
                  >
                    <option value="All">All Sports</option>
                    <option value="Football">Football</option>
                    <option value="Basketball">Basketball</option>
                    <option value="Tennis">Tennis</option>
                  </select>
                  <div className="relative flex-1 sm:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                    <input
                      type="text"
                      placeholder="Search matches..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-lg py-2 pl-10 pr-4 text-xs focus:outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-white/5 border border-white/10 rounded-lg py-2 px-3 text-xs focus:outline-none focus:border-emerald-500/50"
                  >
                    <option value="edge">Edge %</option>
                    <option value="odds">Odds</option>
                    <option value="prob">AI Prob</option>
                    <option value="elite">Elite Picks</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-20 perspective-[2000px]">
                {loading ? (
                  <LoadingSkeleton />
                ) : filteredSignals.length > 0 ? (
                  filteredSignals.map((signal, index) => {
                    const isError = signal.confidence === "ERROR";
                    const isSafePeak =
                      signal.type === "SAFE" ||
                      signal.modelProb >= bettingRules.minProbability;
                    const isValueBet =
                      signal.edge >= bettingRules.valueThreshold && !isSafePeak;
                    const isSmallEdge =
                      signal.edge >= bettingRules.edgeThreshold &&
                      !isValueBet &&
                      !isSafePeak;

                    const decision = isError
                      ? "REJECTED 🛑"
                      : isSafePeak
                        ? "SAFE PEAK 🏔️"
                        : isValueBet
                          ? "VALUE BET 🔥"
                          : isSmallEdge
                            ? "SMALL EDGE ✅"
                            : "NO BET ❌";

                    return (
                      <motion.div
                        key={signal.id || index}
                        initial={{ opacity: 0, y: 20, rotateX: 10 }}
                        animate={{ opacity: 1, y: 0, rotateX: 0 }}
                        whileHover={{ rotateY: 2, rotateX: -2, z: 10 }}
                        transition={{ delay: index * 0.1 }}
                        onClick={() =>
                          setExpandedMatch({ ...signal, decision })
                        }
                        className={`group relative backdrop-blur-xl border p-6 rounded-[2rem] transition-all duration-500 transform-gpu preserve-3d cursor-pointer ${
                          isError
                            ? "bg-red-950/20 border-red-500/20 hover:border-red-500/50"
                            : "bg-[#0F0F11]/80 border-white/5 hover:border-emerald-500/30"
                        }`}
                      >
                        {/* Background Decor */}
                        <div
                          className={`absolute top-0 right-0 w-32 h-32 opacity-5 pointer-events-none transform translate-x-8 -translate-y-8 ${
                            isError
                              ? "bg-red-500 rounded-full"
                              : isValueBet || isSafePeak
                                ? "bg-emerald-500 rounded-full"
                                : ""
                          }`}
                        />

                        {isError && (
                          <div className="absolute inset-0 bg-red-500/5 rounded-[2rem] pointer-events-none border border-red-500/20 animate-pulse" />
                        )}

                        <div className="flex justify-between items-start mb-6">
                          <div className="space-y-1 relative z-10 flex-1">
                            <div className="flex flex-wrap items-center gap-2 mb-2">
                              <span
                                className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                                  isError
                                    ? "bg-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.5)]"
                                    : isSafePeak
                                      ? "bg-indigo-500 text-white shadow-[0_0_15px_rgba(79,70,229,0.3)]"
                                      : isValueBet
                                        ? "bg-emerald-500 text-black shadow-[0_0_15px_rgba(16,185,129,0.3)]"
                                        : isSmallEdge
                                          ? "bg-blue-500 text-white"
                                          : "bg-white/10 text-white/30"
                                }`}
                              >
                                {decision}
                              </span>
                              {signal.realTime ? (
                                <span
                                  className={`text-[8px] font-bold px-2 py-0.5 rounded flex items-center gap-1 border ${
                                    isError
                                      ? "bg-red-500/10 text-red-500 border-red-500/20"
                                      : "bg-red-500/10 text-red-400 border-red-500/20"
                                  }`}
                                >
                                  <div
                                    className={`w-1 h-1 rounded-full animate-pulse ${isError ? "bg-red-600" : "bg-red-500"}`}
                                  />
                                  REAL-TIME
                                </span>
                              ) : (
                                <span className="text-[8px] bg-indigo-500/10 text-indigo-400 font-bold px-2 py-0.5 rounded border border-indigo-500/20">
                                  NEURAL FEED
                                </span>
                              )}
                              <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">
                                {signal.sport ? `${signal.sport} • ` : ""}
                                {signal.league}
                              </span>
                            </div>
                            <h3
                              className={`text-lg font-bold tracking-tight ${isError ? "text-white/60 line-through decoration-red-500/50" : "text-white"}`}
                            >
                              {signal.match}
                            </h3>
                            {signal.bookmaker && (
                              <div className="flex items-center gap-1.5 mt-1">
                                <span
                                  className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 border rounded ${
                                    isError
                                      ? "text-red-500/80 bg-red-500/5 border-red-500/10"
                                      : "text-emerald-500/80 bg-emerald-500/5 border-emerald-500/10"
                                  }`}
                                >
                                  Feed: {signal.bookmaker}
                                </span>
                              </div>
                            )}
                          </div>
                          <div
                            className={`p-3 rounded-2xl group-hover:scale-110 transition-transform ${isError ? "bg-red-500/10" : "bg-white/5"}`}
                          >
                            {isError ? (
                              <ShieldAlert className="w-5 h-5 text-red-500" />
                            ) : (
                              <Activity className="w-5 h-5 text-white/40" />
                            )}
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-2 mb-6 relative z-10">
                          <div
                            className={`p-3 rounded-2xl border ${isError ? "bg-red-950/40 border-red-500/10" : "bg-black/40 border-white/5"}`}
                          >
                            <div className="text-[7px] text-white/20 uppercase font-black mb-1">
                              Market Odds
                            </div>
                            <div
                              className={`text-lg font-mono font-bold ${isError ? "text-red-400/50" : "text-white"} italic`}
                            >
                              {signal.odds.toFixed(2)}
                            </div>
                          </div>
                          <div
                            className={`p-3 rounded-2xl border ${isError ? "bg-red-950/40 border-red-500/10" : "bg-black/40 border-white/5"}`}
                          >
                            <div className="text-[7px] text-white/20 uppercase font-black mb-1">
                              AI Projection
                            </div>
                            <div
                              className={`text-lg font-mono font-bold ${isError ? "text-red-500" : "text-emerald-400"}`}
                            >
                              {(signal.modelProb * 100).toFixed(0)}%
                            </div>
                          </div>
                          <div
                            className={`p-3 rounded-2xl border ${isError ? "bg-red-950/40 border-red-500/10" : "bg-black/40 border-white/5"}`}
                          >
                            <div className="text-[7px] text-white/20 uppercase font-black mb-1">
                              Alpha Edge
                            </div>
                            <div
                              className={`text-lg font-mono font-bold ${isError ? "text-red-600" : signal.edge > 0 ? "text-emerald-500" : "text-white/20"}`}
                            >
                              {signal.edge > 0 ? "+" : ""}
                              {(signal.edge * 100).toFixed(1)}%
                            </div>
                          </div>
                        </div>

                        {/* Reliability Grid */}
                        <div className="grid grid-cols-3 gap-4 mb-6 relative z-10">
                          <div className="group/metric">
                            <div className="text-[7px] text-white/30 uppercase font-black mb-1 group-hover/metric:text-white/60 transition-colors">
                              Reliability
                            </div>
                            <div className="h-1 bg-white/5 rounded-full overflow-hidden mb-1">
                              <motion.div
                                initial={{ width: 0 }}
                                animate={{
                                  width: `${(signal.reliability || (isError ? 0.3 : 0.85)) * 100}%`,
                                }}
                                className={`h-full ${isError ? "bg-red-600" : "bg-emerald-500/50"}`}
                              />
                            </div>
                            <div className="text-[8px] font-mono text-white/40">
                              {(
                                signal.reliability || (isError ? 0.3 : 0.85)
                              ).toFixed(3)}
                            </div>
                          </div>
                          <div className="group/metric">
                            <div className="text-[7px] text-white/30 uppercase font-black mb-1 group-hover/metric:text-white/60 transition-colors">
                              Variance
                            </div>
                            <div className="h-1 bg-white/5 rounded-full overflow-hidden mb-1">
                              <motion.div
                                initial={{ width: 0 }}
                                animate={{
                                  width: `${(signal.variance || (isError ? 0.1 : 0.02)) * 1000}%`,
                                }}
                                className={`h-full ${isError ? "bg-red-400/50" : "bg-indigo-500/50"}`}
                              />
                            </div>
                            <div className="text-[8px] font-mono text-white/40">
                              ±
                              {(
                                signal.variance || (isError ? 0.1 : 0.02)
                              ).toFixed(4)}
                            </div>
                          </div>
                          <div className="group/metric">
                            <div className="text-[7px] text-white/30 uppercase font-black mb-1 group-hover/metric:text-white/60 transition-colors">
                              Confidence Score
                            </div>
                            <div
                              className={`text-[12px] font-mono font-bold transition-colors pt-1 ${
                                isError
                                  ? "text-red-500 group-hover/metric:text-red-400"
                                  : "text-white group-hover/metric:text-emerald-400"
                              }`}
                            >
                              {signal.confidence}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 pt-4 border-t border-white/5 relative z-10">
                          <div className="flex-1">
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-[9px] font-bold text-white/30 uppercase">
                                System Clearance
                              </span>
                              <span
                                className={`text-[9px] font-bold uppercase tracking-widest ${
                                  isError
                                    ? "text-red-500"
                                    : signal.confidence === "High"
                                      ? "text-emerald-400"
                                      : signal.confidence === "Medium"
                                        ? "text-orange-400"
                                        : "text-red-400"
                                }`}
                              >
                                {isError
                                  ? "DENIED BY ENGINE"
                                  : `${signal.confidence} CONFIDENCE`}
                              </span>
                            </div>
                            <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                              <motion.div
                                initial={{ width: 0 }}
                                animate={{
                                  width: isError
                                    ? "15%"
                                    : signal.confidence === "High"
                                      ? "100%"
                                      : signal.confidence === "Medium"
                                        ? "60%"
                                        : "30%",
                                }}
                                className={`h-full ${
                                  isError
                                    ? "bg-red-600 animate-pulse"
                                    : signal.confidence === "High"
                                      ? "bg-emerald-500"
                                      : signal.confidence === "Medium"
                                        ? "bg-orange-500"
                                        : "bg-red-500"
                                }`}
                              />
                            </div>
                          </div>
                          <button
                            disabled={isError}
                            className={`px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${
                              isError
                                ? "bg-red-950/50 text-red-500/50 border border-red-900/50 cursor-not-allowed"
                                : "bg-[#10b981] text-black hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(16,185,129,0.3)]"
                            }`}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (isError) return;
                              // Logic for linking to bookmaker could go here
                            }}
                          >
                            {isError ? (
                              <ShieldAlert className="w-3 h-3" />
                            ) : (
                              <TrendingUp className="w-3 h-3" />
                            )}
                            {isError ? "BLOCKED" : signal.bookmaker || "1xBet"}
                          </button>
                        </div>
                      </motion.div>
                    );
                  })
                ) : (
                  !loading && (
                    <div className="col-span-2 p-12 text-center border border-dashed border-white/10 rounded-2xl">
                      <div className="text-white/20 text-xs font-mono uppercase">
                        No matching signals identified in current feed
                      </div>
                    </div>
                  )
                )}
              </div>
            </>
          ) : activeTab === "chat" ? (
            <div className="h-[70vh] flex flex-col bg-white/5 border border-white/10 rounded-3xl overflow-hidden animate-in fade-in slide-in-from-right-4 duration-500">
              {/* Chat Header */}
              <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-500 rounded-lg shadow-[0_0_15px_rgba(99,102,241,0.3)]">
                    <MessageSquare className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold uppercase tracking-widest">
                      AI Prediction Oracle
                    </h3>
                    <div className="text-[10px] text-indigo-400 font-mono uppercase">
                      Grounded in Google Search • V4.2a
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[8px] font-bold text-emerald-400 uppercase">
                    Neural Link Sync
                  </span>
                </div>
              </div>

              {/* Chat Messages */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin">
                {user ? (
                  chatMessages.length > 0 ? (
                    chatMessages.map((msg, i) => (
                      <motion.div
                        key={msg.id || i}
                        initial={{
                          opacity: 0,
                          x: msg.sender === "user" ? 20 : -20,
                        }}
                        animate={{ opacity: 1, x: 0 }}
                        className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[80%] p-4 rounded-2xl text-sm relative group/msg ${
                            msg.sender === "user"
                              ? "bg-indigo-500 text-white rounded-tr-none"
                              : "bg-white/10 text-white/90 border border-white/10 rounded-tl-none font-mono text-xs"
                          }`}
                        >
                          {msg.text}
                          {msg.sender === "ai" && (
                            <button
                              onClick={() => voiceService.speak(msg.text, true)}
                              className="absolute -right-8 top-0 p-2 opacity-0 group-hover/msg:opacity-100 transition-opacity text-white/20 hover:text-white"
                              title="Vocalize Response"
                              type="button"
                            >
                              <Radio className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </motion.div>
                    ))
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center p-12 opacity-30">
                      <Sparkles className="w-12 h-12 mb-4" />
                      <p className="text-xs font-mono uppercase tracking-widest">
                        Awaiting prompt. Inquire about matches, prop shops, or
                        market trends.
                      </p>
                    </div>
                  )
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-12">
                    <ShieldCheck className="w-12 h-12 mb-4 text-white/20" />
                    <h4 className="text-sm font-bold mb-2">AUTH REQUIRED</h4>
                    <p className="text-xs text-white/40 mb-6 max-w-xs">
                      Please sign in to access the private neural link and
                      persist your chat history.
                    </p>
                    <button
                      onClick={handleSignIn}
                      className="px-6 py-3 bg-white text-black rounded-xl text-xs font-bold uppercase transition-all hover:scale-105 active:scale-95"
                    >
                      Secure Sign In
                    </button>
                  </div>
                )}
              </div>

              {/* Chat Input */}
              {user && (
                <form
                  onSubmit={sendMessage}
                  className="p-6 bg-white/5 border-t border-white/5"
                >
                  <div className="relative">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Ask the Oracle about today's value signals..."
                      className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-6 pr-16 text-sm focus:outline-none focus:border-indigo-500/50 transition-all"
                    />
                    <button
                      type="submit"
                      disabled={isSending || !chatInput.trim()}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-3 bg-indigo-500 rounded-xl text-white hover:bg-indigo-400 disabled:opacity-30 disabled:hover:bg-indigo-500"
                    >
                      {isSending ? (
                        <RefreshCcw className="w-4 h-4 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <div className="flex gap-4">
                      <button
                        type="button"
                        onClick={() => setUseSearch(!useSearch)}
                        className={`flex items-center gap-1 text-[8px] font-bold uppercase tracking-widest transition-all ${
                          useSearch ? "text-emerald-400" : "text-white/20"
                        }`}
                      >
                        <Globe className="w-2.5 h-2.5" /> Google Search{" "}
                        {useSearch ? "Active" : "Off"}
                      </button>
                      <button
                        type="button"
                        className="flex items-center gap-1 text-[8px] font-bold uppercase tracking-widest text-blue-400/50 hover:text-blue-400 transition-all"
                      >
                        <Database className="w-2.5 h-2.5" /> Workspace Sync
                      </button>
                    </div>
                    <span className="text-[8px] font-mono text-white/10">
                      Neural Engine v5.2
                    </span>
                  </div>
                </form>
              )}
            </div>
          ) : (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Institutional Flow Simulation */}
                <div className="col-span-1 md:col-span-2 bg-black/40 backdrop-blur-xl p-8 rounded-[3rem] border border-white/10 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-6">
                    <div className="px-3 py-1 bg-blue-500/10 text-blue-400 text-[10px] font-black rounded-full border border-blue-500/20 uppercase tracking-widest animate-pulse">
                      Neural Flux: Stable
                    </div>
                  </div>
                  <div className="flex justify-between items-center mb-10">
                    <div>
                      <h3 className="text-xl font-black text-white uppercase tracking-tighter italic">
                        Institutional Liquidity Drift
                      </h3>
                      <p className="text-[10px] text-white/30 uppercase font-mono tracking-widest">
                        Global Order Book Anomaly Detection
                      </p>
                    </div>
                  </div>
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={[
                          { time: "00:00", flow: 400, depth: 200 },
                          { time: "04:00", flow: 300, depth: 250 },
                          { time: "08:00", flow: 600, depth: 400 },
                          { time: "12:00", flow: 800, depth: 300 },
                          { time: "16:00", flow: 1200, depth: 600 },
                          { time: "20:00", flow: 1500, depth: 800 },
                          { time: "23:59", flow: 1100, depth: 500 },
                        ]}
                      >
                        <defs>
                          <linearGradient
                            id="colorFlow"
                            x1="0"
                            y1="0"
                            x2="0"
                            y2="1"
                          >
                            <stop
                              offset="5%"
                              stopColor="#3b82f6"
                              stopOpacity={0.4}
                            />
                            <stop
                              offset="95%"
                              stopColor="#3b82f6"
                              stopOpacity={0}
                            />
                          </linearGradient>
                          <linearGradient
                            id="colorDepth"
                            x1="0"
                            y1="0"
                            x2="0"
                            y2="1"
                          >
                            <stop
                              offset="5%"
                              stopColor="#10b981"
                              stopOpacity={0.2}
                            />
                            <stop
                              offset="95%"
                              stopColor="#10b981"
                              stopOpacity={0}
                            />
                          </linearGradient>
                        </defs>
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke="#ffffff05"
                          vertical={false}
                        />
                        <XAxis dataKey="time" stroke="#ffffff20" fontSize={9} />
                        <YAxis stroke="#ffffff20" fontSize={9} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#0f0f11",
                            border: "1px solid #ffffff10",
                            borderRadius: "16px",
                            fontSize: "10px",
                          }}
                          itemStyle={{ color: "#fff" }}
                        />
                        <Area
                          type="monotone"
                          dataKey="flow"
                          stroke="#3b82f6"
                          strokeWidth={3}
                          fillOpacity={1}
                          fill="url(#colorFlow)"
                        />
                        <Area
                          type="monotone"
                          dataKey="depth"
                          stroke="#10b981"
                          strokeWidth={2}
                          fillOpacity={1}
                          fill="url(#colorDepth)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                      <div className="text-[8px] text-white/20 uppercase font-black mb-1">
                        Buy Pressure
                      </div>
                      <div className="text-lg font-mono font-bold text-blue-400">
                        74.2%
                      </div>
                    </div>
                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                      <div className="text-[8px] text-white/20 uppercase font-black mb-1">
                        Drift Coeff
                      </div>
                      <div className="text-lg font-mono font-bold text-white">
                        +1.42
                      </div>
                    </div>
                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                      <div className="text-[8px] text-white/20 uppercase font-black mb-1">
                        Volatility
                      </div>
                      <div className="text-lg font-mono font-bold text-red-400">
                        LOW
                      </div>
                    </div>
                    <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                      <div className="text-[8px] text-white/20 uppercase font-black mb-1">
                        Sync Index
                      </div>
                      <div className="text-lg font-mono font-bold text-emerald-400">
                        0.98
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 border border-white/10 p-8 rounded-3xl group hover:border-emerald-500/30 transition-all">
                  <div className="flex items-center justify-between mb-4">
                    <BarChart3 className="w-8 h-8 text-emerald-500" />
                    <div className="text-[10px] font-mono text-white/20 uppercase tracking-[0.2em]">
                      Overall Efficiency
                    </div>
                  </div>
                  <div className="text-4xl font-bold tracking-tighter mb-1 text-white">
                    {(metrics?.roi.total || 0).toFixed(1)}%
                  </div>
                  <div className="text-xs text-emerald-400 font-bold uppercase tracking-widest">
                    Total Model ROI
                  </div>
                  <div className="mt-6 pt-6 border-t border-white/5 flex justify-between text-[10px] font-mono text-white/30">
                    <span>WIN RATE</span>
                    <span className="text-emerald-400">
                      {(metrics?.accuracy.overall || 0 * 100).toFixed(1)}%
                    </span>
                  </div>
                </div>

                <div className="bg-white/5 border border-white/10 p-8 rounded-3xl group hover:border-blue-500/30 transition-all">
                  <div className="flex items-center justify-between mb-4">
                    <Target className="w-8 h-8 text-blue-500" />
                    <div className="text-[10px] font-mono text-white/20 uppercase tracking-[0.2em]">
                      Predictive Power
                    </div>
                  </div>
                  <div className="text-4xl font-bold tracking-tighter mb-1 text-white">
                    {metrics?.profitableSignals}
                  </div>
                  <div className="text-xs text-blue-400 font-bold uppercase tracking-widest">
                    Profitable Signals
                  </div>
                  <div className="mt-6 pt-6 border-t border-white/5 flex justify-between text-[10px] font-mono text-white/30">
                    <span>TOTAL PROCESSED</span>
                    <span className="text-blue-400">
                      {metrics?.signalsProcessed}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 border border-white/10 p-8 rounded-3xl">
                <div className="flex items-center gap-3 mb-8">
                  <TrendingUp className="w-5 h-5 text-emerald-500" />
                  <h3 className="text-sm font-bold uppercase tracking-widest">
                    Market Distribution
                  </h3>
                </div>
                <div className="h-64 w-full mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        {
                          sport: "Football",
                          accuracy: Number(
                            ((metrics?.accuracy.football || 0) * 100).toFixed(
                              1,
                            ),
                          ),
                        },
                        {
                          sport: "Basketball",
                          accuracy: Number(
                            ((metrics?.accuracy.basketball || 0) * 100).toFixed(
                              1,
                            ),
                          ),
                        },
                      ]}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="#ffffff05"
                        vertical={false}
                      />
                      <XAxis
                        dataKey="sport"
                        stroke="#ffffff20"
                        fontSize={10}
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        stroke="#ffffff20"
                        fontSize={10}
                        tickLine={false}
                        axisLine={false}
                        domain={[0, 100]}
                      />
                      <Tooltip
                        cursor={{ fill: "#ffffff05" }}
                        contentStyle={{
                          backgroundColor: "#0f0f11",
                          border: "1px solid #ffffff10",
                          borderRadius: "16px",
                          fontSize: "10px",
                        }}
                        itemStyle={{ color: "#10b981" }}
                        formatter={(value: any) => [`${value}%`, "Accuracy"]}
                      />
                      <Bar
                        dataKey="accuracy"
                        fill="#10b981"
                        radius={[4, 4, 0, 0]}
                        barSize={40}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-8 p-4 bg-white/5 rounded-2xl border border-white/5">
                  <div className="flex items-center gap-3">
                    <AlertCircle className="w-4 h-4 text-emerald-400" />
                    <p className="text-[10px] text-white/50 leading-relaxed font-mono uppercase tracking-tighter">
                      Metics are calculated based on closing market odds and
                      historical signal drift. Past performance does not
                      guarantee future alpha.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Active Feed & Insights */}
        <div className="col-span-12 lg:col-span-4 space-y-8">
          {/* AI Oracle Future Outlook */}
          <div className="bg-gradient-to-br from-indigo-500/10 to-emerald-500/10 border border-white/10 rounded-2xl p-6 relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 to-emerald-500" />
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-indigo-400">
                <Sparkles className="w-4 h-4" /> AI Future Oracle
              </div>
              <button
                onClick={generateAiFuture}
                disabled={isAiLoading}
                className="p-1 hover:bg-white/5 rounded transition-transform active:rotate-180 disabled:opacity-30"
              >
                <RefreshCcw
                  className={`w-3 h-3 ${isAiLoading ? "animate-spin" : ""}`}
                />
              </button>
            </div>

            <div
              className={`text-xs leading-relaxed text-white/70 italic font-mono space-y-3 transition-opacity ${isAiLoading ? "opacity-30" : "opacity-100"}`}
            >
              {aiInsights ? (
                aiInsights
                  .split("\n")
                  .filter((l) => l.trim())
                  .map((line, i) => (
                    <div key={i} className="flex gap-2">
                      <span className="text-indigo-400 opacity-50">#</span>
                      <span>
                        {line.replace(/^-\s*/, "").replace(/^\d\.\s*/, "")}
                      </span>
                    </div>
                  ))
              ) : (
                <div className="space-y-2">
                  <div className="h-2 bg-white/5 rounded w-full" />
                  <div className="h-2 bg-white/5 rounded w-3/4" />
                </div>
              )}
            </div>

            <div className="mt-6 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-bold uppercase tracking-tighter text-white/20">
                System Prediction Engine v5.2a Offline-Sync
              </span>
            </div>
          </div>
          {/* Quick Stats Panel */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-sm font-bold uppercase tracking-widest mb-6 flex items-center gap-2">
              <Trophy className="w-4 h-4 text-emerald-500" /> Daily Top
              Performers
            </h3>
            <div className="space-y-4">
              {matches.map((m) => (
                <div
                  key={m.id}
                  className="flex items-center gap-4 group p-3 hover:bg-white/5 rounded-xl transition-all cursor-pointer"
                >
                  <div className="w-10 h-10 bg-black/40 rounded-lg flex items-center justify-center border border-white/5">
                    <ArrowUpRight className="w-4 h-4 text-emerald-500 group-hover:scale-110 transition-transform" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <div className="text-[10px] font-mono text-emerald-400 tracking-tighter">
                        {m.league}
                      </div>
                      {m.realTime && (
                        <div className="w-1 h-1 bg-red-500 rounded-full animate-pulse" />
                      )}
                    </div>
                    <div className="text-xs font-bold text-white/80">
                      {m.homeTeam} v {m.awayTeam}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-white/30 font-mono tracking-tighter">
                      {m.time}
                    </div>
                    <div className="text-[9px] text-white/20 uppercase font-bold">
                      In-PlaySoon
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AI Orchestrator Tip */}
          <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-2xl p-6 relative overflow-hidden">
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl" />
            <div className="flex items-center gap-2 mb-4">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-bold uppercase tracking-widest text-emerald-400">
                Model Insight
              </h3>
            </div>
            <p className="text-xs leading-relaxed text-white/70 italic font-mono">
              "System is tracking excessive volume on{" "}
              {signals[0]?.match.split("vs")[0]}. Edge detection confirms
              institutional drift. High confidence in value bet #1."
            </p>
            <div className="mt-4 pt-4 border-t border-emerald-500/10 text-[9px] uppercase tracking-widest font-mono text-emerald-400/40">
              Orchestration Engine v4.0 Active
            </div>
          </div>

          {/* Live System Logs */}
          <div className="bg-black/20 border border-white/5 rounded-2xl p-6">
            <h3 className="text-[10px] font-mono uppercase tracking-[0.3em] text-white/20 mb-4">
              Real-time Feed Logs
            </h3>
            <div className="space-y-2 max-h-[150px] overflow-hidden opacity-40 font-mono text-[9px]">
              <div className="flex gap-2">
                <span className="text-emerald-500">[FETCH]</span>
                <span>Polling Odds-API v4 endpoints...</span>
              </div>
              <div className="flex gap-2">
                <span className="text-emerald-500">[VALUE]</span>
                <span>Edge detected {signals[0]?.match} (7.2%)</span>
              </div>
              <div className="flex gap-2 text-white/40">
                <span className="">[TICK]</span>
                <span>Heartbeat check: Service OK</span>
              </div>
              <div className="flex gap-2">
                <span className="text-emerald-500">[FETCH]</span>
                <span>Piping sportsdata signals...</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Signal Detail Modal */}
      <AnimatePresence>
        {selectedSignal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedSignal(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="w-full max-w-lg bg-[#0F0F11] border border-white/10 rounded-3xl overflow-hidden relative"
            >
              <div className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-[9px] font-bold text-emerald-400 tracking-widest uppercase">
                        {selectedSignal.sport}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-white/5 text-[9px] font-bold text-white/40 tracking-widest uppercase">
                        {selectedSignal.league}
                      </span>
                    </div>
                    <h2 className="text-2xl font-bold tracking-tighter text-white">
                      {selectedSignal.match}
                    </h2>
                  </div>
                  <button
                    onClick={() => setSelectedSignal(null)}
                    className="p-2 hover:bg-white/5 rounded-full"
                  >
                    <X className="w-5 h-5 text-white/40" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="bg-white/5 border border-white/5 p-4 rounded-2xl">
                    <div className="text-[9px] uppercase tracking-widest text-white/30 mb-1">
                      Implied Probability
                    </div>
                    <div className="text-xl font-mono font-bold">
                      {(selectedSignal.impliedProb * 100).toFixed(1)}%
                    </div>
                    <div className="text-[10px] text-white/20 mt-1">
                      Based on market odds
                    </div>
                  </div>
                  <div className="bg-emerald-500/5 border border-emerald-500/10 p-4 rounded-2xl">
                    <div className="text-[9px] uppercase tracking-widest text-emerald-400/50 mb-1">
                      AI Model Confidence
                    </div>
                    <div className="text-xl font-mono font-bold text-emerald-400">
                      {(selectedSignal.modelProb * 100).toFixed(1)}%
                    </div>
                    <div className="text-[10px] text-emerald-500/30 mt-1">
                      Hedge-adjusted forecast
                    </div>
                  </div>
                </div>

                <div className="space-y-4 mb-8">
                  <div className="flex justify-between items-center text-sm border-b border-white/5 pb-3">
                    <span className="text-white/40 flex items-center gap-2">
                      <ArrowUpRight className="w-4 h-4" /> Market Odds (Decimal)
                    </span>
                    <span className="font-mono text-white">
                      {selectedSignal.odds.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-sm border-b border-white/5 pb-3">
                    <span className="text-white/40 flex items-center gap-2">
                      <Briefcase className="w-4 h-4" /> Calculated Edge
                    </span>
                    <span className="font-mono text-emerald-400">
                      +{(selectedSignal.edge * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-sm border-b border-white/5 pb-3">
                    <span className="text-white/40 flex items-center gap-2">
                      <Clock className="w-4 h-4" /> Signal Integrity
                    </span>
                    <span className="text-white/60">
                      Verified {lastUpdated.toLocaleTimeString()}
                    </span>
                  </div>
                </div>

                <div
                  className={`p-4 rounded-2xl border flex items-center gap-4 ${
                    selectedSignal.edge >= bettingRules.valueThreshold
                      ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                      : "bg-white/5 border-white/10 text-white"
                  }`}
                >
                  <div
                    className={`p-2 rounded-lg ${selectedSignal.edge >= bettingRules.valueThreshold ? "bg-emerald-500 text-black" : "bg-white/10"}`}
                  >
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[10px] uppercase font-bold tracking-widest opacity-60">
                      System Verdict
                    </div>
                    <div className="text-lg font-bold tracking-tight">
                      {selectedSignal.decision}
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 ml-auto opacity-30 px-3" />
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Notifications Toast */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
        <AnimatePresence>
          {notifications.map((n) => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.9 }}
              className={`px-4 py-3 rounded-xl border flex items-center gap-3 shadow-[0_10px_20px_rgba(0,0,0,0.4)] ${
                n.type === "success"
                  ? "bg-emerald-950/80 border-emerald-500/50 text-emerald-400"
                  : n.type === "alert"
                    ? "bg-orange-950/80 border-orange-500/50 text-orange-400"
                    : "bg-red-950/80 border-red-500/50 text-red-400"
              }`}
            >
              {n.type === "success" && <CheckCircle className="w-4 h-4" />}
              {n.type === "alert" && <RefreshCcw className="w-4 h-4" />}
              {n.type === "error" && <X className="w-4 h-4" />}
              <span className="text-sm font-bold tracking-tight">{n.msg}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Add Ledger Record Modal */}
      <AnimatePresence>
        {showAddTaxRecord && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddTaxRecord(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              className="w-full max-w-md bg-[#0F0F11] border border-white/10 rounded-3xl overflow-hidden relative p-8"
            >
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-xl font-bold tracking-tighter text-white">
                  Add Ledger Record
                </h2>
                <button
                  onClick={() => setShowAddTaxRecord(false)}
                  className="p-2 hover:bg-white/5 rounded-full"
                >
                  <X className="w-5 h-5 text-white/40" />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] uppercase font-bold tracking-widest text-white/40 mb-2 block">
                    Event / Game Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Arsenal vs Chelsea"
                    value={newTaxRecord.eventName}
                    onChange={(e) =>
                      setNewTaxRecord({
                        ...newTaxRecord,
                        eventName: e.target.value,
                      })
                    }
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-emerald-500/50"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold tracking-widest text-white/40 mb-2 block">
                      Sport
                    </label>
                    <select
                      value={newTaxRecord.sport}
                      onChange={(e) =>
                        setNewTaxRecord({
                          ...newTaxRecord,
                          sport: e.target.value,
                        })
                      }
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-emerald-500/50 appearance-none"
                    >
                      <option value="Football">Football</option>
                      <option value="Basketball">Basketball</option>
                      <option value="Tennis">Tennis</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold tracking-widest text-white/40 mb-2 block">
                      Prediction
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Over 2.5"
                      value={newTaxRecord.predictionType}
                      onChange={(e) =>
                        setNewTaxRecord({
                          ...newTaxRecord,
                          predictionType: e.target.value,
                        })
                      }
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-emerald-500/50"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold tracking-widest text-emerald-400 mb-2 block">
                      Profit ($)
                    </label>
                    <input
                      type="number"
                      value={newTaxRecord.profit}
                      onChange={(e) =>
                        setNewTaxRecord({
                          ...newTaxRecord,
                          profit: parseFloat(e.target.value) || 0,
                        })
                      }
                      className="w-full bg-emerald-500/5 border border-emerald-500/20 rounded-xl px-4 py-3 text-emerald-400 font-mono text-sm focus:outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold tracking-widest text-rose-400 mb-2 block">
                      Loss ($)
                    </label>
                    <input
                      type="number"
                      value={newTaxRecord.loss}
                      onChange={(e) =>
                        setNewTaxRecord({
                          ...newTaxRecord,
                          loss: parseFloat(e.target.value) || 0,
                        })
                      }
                      className="w-full bg-rose-500/5 border border-rose-500/20 rounded-xl px-4 py-3 text-rose-400 font-mono text-sm focus:outline-none focus:border-rose-500/50"
                    />
                  </div>
                </div>
                <button
                  onClick={async () => {
                    if (!user) return;
                    await addDoc(
                      collection(db, "users", user.uid, "tax_records"),
                      {
                        userId: user.uid,
                        eventName: newTaxRecord.eventName || "Unknown Event",
                        predictionType: newTaxRecord.predictionType || "Win",
                        sport: newTaxRecord.sport || "Football",
                        profit: newTaxRecord.profit,
                        loss: newTaxRecord.loss,
                        updatedAt: serverTimestamp(),
                        notes: "",
                      },
                    );
                    setShowAddTaxRecord(false);
                    setNewTaxRecord({
                      eventName: "",
                      predictionType: "",
                      sport: "Football",
                      profit: 0,
                      loss: 0,
                    });
                    addNotification(
                      "Record successfully added to ledger.",
                      "success",
                    );
                  }}
                  className="w-full py-4 mt-4 bg-emerald-500 text-black font-black uppercase tracking-widest rounded-xl hover:bg-emerald-400 transition-colors"
                >
                  Save Record
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Match Details Modal for Deep Analysis */}
      <AnimatePresence>
        {expandedMatch && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setExpandedMatch(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              className="w-full max-w-2xl bg-[#0F0F11] border border-emerald-500/20 rounded-[2.5rem] overflow-hidden relative p-8 shadow-[0_0_50px_rgba(16,185,129,0.1)] max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-start mb-6">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-1 bg-emerald-500/10 text-emerald-500 text-[10px] font-black rounded-lg uppercase tracking-wider border border-emerald-500/20">
                      Alpha Signal Target
                    </span>
                    {expandedMatch.realTime && (
                      <span className="px-2 py-1 bg-red-500 text-white rounded font-mono text-[8px] uppercase font-bold animate-pulse">
                        Live Tracker
                      </span>
                    )}
                  </div>
                  <h2 className="text-3xl font-black tracking-tighter text-white uppercase italic">
                    {expandedMatch.match ||
                      expandedMatch.homeTeam + " vs " + expandedMatch.awayTeam}
                  </h2>
                  <p className="text-xs font-mono text-emerald-500 uppercase mt-1">
                    {expandedMatch.league || "Global Match"} • ID:{" "}
                    {expandedMatch.id.toString().slice(0, 6)}
                  </p>
                </div>
                <button
                  onClick={() => setExpandedMatch(null)}
                  className="p-3 bg-white/5 hover:bg-white/10 rounded-2xl transition-all"
                >
                  <X className="w-5 h-5 text-white/60" />
                </button>
              </div>

              <div className="bg-gradient-to-r from-emerald-900/40 to-black p-6 rounded-3xl border border-emerald-500/10 mb-6">
                <h3 className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                  <Target className="w-4 h-4" /> Safest Pick Recommendation
                </h3>
                <div className="flex items-end justify-between">
                  <div>
                    <div className="text-2xl font-black text-white italic">
                      {expandedMatch.market || "Draw No Bet"}
                    </div>
                    <div className="text-xs font-mono text-white/50 uppercase mt-1">
                      Algorithmic Confidence:{" "}
                      <span
                        className={
                          expandedMatch.confidence === "High"
                            ? "text-emerald-400"
                            : expandedMatch.confidence === "Medium"
                              ? "text-orange-400"
                              : "text-emerald-400"
                        }
                      >
                        {expandedMatch.confidence || "High"}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex gap-4">
                      <div className="text-right">
                        <div className="text-sm font-mono text-white/40 tracking-tighter line-through decoration-red-500/50">
                          {expandedMatch.odds
                            ? ((1 / expandedMatch.odds) * 100).toFixed(0)
                            : (65 + Math.random() * 20).toFixed(0)}
                          %
                        </div>
                        <div className="text-[7px] text-white/20 uppercase font-black tracking-widest mt-1">
                          Market Prob
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-mono text-emerald-500 tracking-tighter">
                          {expandedMatch.prob
                            ? (expandedMatch.prob * 100).toFixed(0)
                            : (75 + Math.random() * 20).toFixed(0)}
                          %
                        </div>
                        <div className="text-[9px] text-emerald-500/50 uppercase font-black tracking-widest mt-1">
                          Model Prob
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-sm font-bold tracking-widest text-white/40 uppercase mb-4">
                  Deep Market Projections
                </h3>

                <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div className="text-[9px] text-white/40 uppercase font-bold mb-1">
                      Match Result
                    </div>
                    <div className="text-sm font-bold text-white">
                      {expandedMatch.market ||
                        (Math.random() > 0.5 ? "Home Win" : "Away Win")}
                    </div>
                  </div>
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div className="text-[9px] text-white/40 uppercase font-bold mb-1">
                      BTTS
                    </div>
                    <div className="text-sm font-bold text-white">
                      {Math.random() > 0.4 ? "YES" : "NO"}{" "}
                      <span className="text-emerald-500 font-mono text-[10px]">
                        {(60 + Math.random() * 30).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div className="text-[9px] text-white/40 uppercase font-bold mb-1">
                      Total Goals
                    </div>
                    <div className="text-sm font-bold text-white">
                      Over 1.5{" "}
                      <span className="text-emerald-500 font-mono text-[10px]">
                        {(80 + Math.random() * 15).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div className="text-[9px] text-white/40 uppercase font-bold mb-1">
                      Total Corners
                    </div>
                    <div className="text-sm font-bold text-white">
                      Over 8.5{" "}
                      <span className="text-emerald-500 font-mono text-[10px]">
                        {(55 + Math.random() * 40).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div className="text-[9px] text-white/40 uppercase font-bold mb-1">
                      Total Cards
                    </div>
                    <div className="text-sm font-bold text-white">
                      Under 4.5{" "}
                      <span className="text-emerald-500 font-mono text-[10px]">
                        {(60 + Math.random() * 25).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div className="text-[9px] text-white/40 uppercase font-bold mb-1">
                      Team to Score First
                    </div>
                    <div className="text-sm font-bold text-white">
                      {expandedMatch.homeTeam || "Home"}{" "}
                      <span className="text-emerald-500 font-mono text-[10px]">
                        {(50 + Math.random() * 35).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                </div>

                <h3 className="text-sm font-bold tracking-widest text-white/40 uppercase mt-8 mb-4 border-t border-white/10 pt-6">
                  Exotic Events & Threats
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-4 bg-red-500/5 rounded-2xl border border-red-500/10">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[9px] text-red-400 uppercase font-bold">
                        Red Card Probability
                      </span>
                      <span className="text-xs font-mono text-red-500">
                        {(5 + Math.random() * 15).toFixed(1)}%
                      </span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden mt-2">
                      <div
                        className="h-full bg-red-500"
                        style={{ width: `${5 + Math.random() * 15}%` }}
                      ></div>
                    </div>
                  </div>
                  <div className="p-4 bg-orange-500/5 rounded-2xl border border-orange-500/10">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[9px] text-orange-400 uppercase font-bold">
                        Penalty Probability
                      </span>
                      <span className="text-xs font-mono text-orange-500">
                        {(15 + Math.random() * 30).toFixed(1)}%
                      </span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden mt-2">
                      <div
                        className="h-full bg-orange-500"
                        style={{ width: `${15 + Math.random() * 30}%` }}
                      ></div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-white/5 rounded-2xl border border-white/10 mt-4 text-center">
                  <div className="text-[10px] text-white/40 uppercase mb-2 font-bold font-mono">
                    Team Strength Analysis
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="text-sm font-bold text-white">
                      {expandedMatch.homeTeam || "Home"}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-emerald-500 font-mono text-xs">
                        {(40 + Math.random() * 40).toFixed(0)}%
                      </span>
                      <span className="text-[8px] text-white/20">vs</span>
                      <span className="text-emerald-500 font-mono text-xs">
                        {(40 + Math.random() * 40).toFixed(0)}%
                      </span>
                    </div>
                    <div className="text-sm font-bold text-white">
                      {expandedMatch.awayTeam || "Away"}
                    </div>
                  </div>
                </div>

                {expandedMatch.type === "ELITE" && (
                  <button
                    onClick={() => {
                      window.open(
                        `https://example.com/bet?market=${encodeURIComponent(expandedMatch.market)}&odds=${expandedMatch.odds}`,
                        "_blank",
                      );
                    }}
                    className="w-full mt-4 py-4 bg-emerald-500 text-black font-black uppercase tracking-widest rounded-xl hover:bg-emerald-400 transition-colors flex justify-center items-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.3)]"
                  >
                    Execute Elite Pick
                    <ArrowRight className="w-4 h-4 text-black" />
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettings && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettings(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="w-full max-w-md bg-[#0F0F11] border border-white/10 rounded-3xl overflow-hidden relative p-8"
            >
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-xl font-bold tracking-tighter text-white">
                  Engine Calibration
                </h2>
                <button
                  onClick={() => setShowSettings(false)}
                  className="p-2 hover:bg-white/5 rounded-full"
                >
                  <X className="w-5 h-5 text-white/40" />
                </button>
              </div>

              <div className="space-y-8">
                <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-2 rounded-lg ${theme === "dark" ? "bg-indigo-500" : "bg-amber-500"}`}
                    >
                      {theme === "dark" ? (
                        <Moon className="w-4 h-4 text-white" />
                      ) : (
                        <Sun className="w-4 h-4 text-white" />
                      )}
                    </div>
                    <div>
                      <div className="text-[10px] font-bold text-white uppercase">
                        Visual Interface
                      </div>
                      <div className="text-[8px] text-white/40 uppercase">
                        {theme === "dark"
                          ? "Neural Night Mode"
                          : "Photon Day Mode"}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      const newTheme = theme === "dark" ? "light" : "dark";
                      setTheme(newTheme);
                      if (user) {
                        await setDoc(
                          doc(db, "users", user.uid),
                          { theme: newTheme },
                          { merge: true },
                        );
                      }
                    }}
                    className={`w-12 h-6 rounded-full relative transition-all duration-300 ${theme === "dark" ? "bg-indigo-500" : "bg-amber-500"}`}
                  >
                    <motion.div
                      animate={{ x: theme === "dark" ? 24 : 4 }}
                      className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-lg"
                    />
                  </button>
                </div>

                <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-white/5">
                      <HelpCircle className="w-4 h-4 text-white/20" />
                    </div>
                    <div>
                      <div className="text-[10px] font-bold text-white uppercase">
                        System Tutorial
                      </div>
                      <div className="text-[8px] text-white/40 uppercase">
                        Reset onboarding sequence
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setOnboardingStep(1)}
                    className="px-3 py-1 bg-white/10 hover:bg-white/20 rounded-lg text-[10px] font-bold uppercase transition-all"
                  >
                    Reset
                  </button>
                </div>

                <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                  <div className="flex items-center gap-3">
                    <div
                      className={`p-2 rounded-lg ${voiceEnabled ? "bg-emerald-500" : "bg-white/5"}`}
                    >
                      <Radio
                        className={`w-4 h-4 ${voiceEnabled ? "text-black" : "text-white/20"}`}
                      />
                    </div>
                    <div>
                      <div className="text-[10px] font-bold text-white uppercase">
                        Vocalize Oracle
                      </div>
                      <div className="text-[8px] text-white/40 uppercase">
                        Voice synthesis for insights
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      const newState = !voiceEnabled;
                      setVoiceEnabled(newState);
                      voiceService.setEnabled(newState);
                      if (newState)
                        voiceService.speak(
                          "Neural voice link stabilized. Oracle is online.",
                          true,
                        );
                    }}
                    className={`w-12 h-6 rounded-full relative transition-all duration-300 ${voiceEnabled ? "bg-emerald-500" : "bg-white/10"}`}
                  >
                    <motion.div
                      animate={{ x: voiceEnabled ? 24 : 4 }}
                      className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-lg"
                    />
                  </button>
                </div>

                <div className="relative">
                  <div className="flex justify-between mb-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">
                      Value Bet Threshold
                    </label>
                    <div className="flex items-center gap-2">
                      {metrics && metrics.accuracy.overall > 0.6 && (
                        <span className="text-[8px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20 font-bold">
                          AI REC:{" "}
                          {(bettingRules.valueThreshold * 100).toFixed(0)}%
                        </span>
                      )}
                      <span className="text-xs font-mono">
                        {(bettingRules.valueThreshold * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="0.2"
                    step="0.01"
                    value={bettingRules.valueThreshold}
                    onChange={(e) =>
                      setBettingRules({
                        ...bettingRules,
                        valueThreshold: parseFloat(e.target.value),
                      })
                    }
                    className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                  />
                  <p className="text-[9px] text-white/30 mt-2 font-mono uppercase">
                    Defines when a signal is marked as HIGH CONFIDENCE ALPHA.
                  </p>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-blue-400">
                      Small Edge Threshold
                    </label>
                    <span className="text-xs font-mono">
                      {(bettingRules.edgeThreshold * 100).toFixed(0)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="0.1"
                    step="0.01"
                    value={bettingRules.edgeThreshold}
                    onChange={(e) =>
                      setBettingRules({
                        ...bettingRules,
                        edgeThreshold: parseFloat(e.target.value),
                      })
                    }
                    className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-blue-500"
                  />
                  <p className="text-[9px] text-white/30 mt-2 font-mono uppercase">
                    Minimum edge required to display a positive signal.
                  </p>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">
                      Safe Peak Min Confidence
                    </label>
                    <span className="text-xs font-mono">
                      {(bettingRules.minProbability * 100).toFixed(0)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="0.95"
                    step="0.01"
                    value={bettingRules.minProbability || 0.75}
                    onChange={(e) =>
                      setBettingRules({
                        ...bettingRules,
                        minProbability: parseFloat(e.target.value),
                      })
                    }
                    className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                  />
                  <p className="text-[9px] text-white/30 mt-2 font-mono uppercase">
                    Minimum probability for SAFE PEAK designation.
                  </p>
                </div>

                <button
                  onClick={calibrateThresholds}
                  disabled={isCalibrating}
                  className="w-full py-4 bg-white/5 border border-dashed border-emerald-500/50 rounded-2xl flex items-center justify-center gap-3 group hover:bg-emerald-500/10 transition-all disabled:opacity-50"
                >
                  <Zap
                    className={`w-4 h-4 text-emerald-400 ${isCalibrating ? "animate-bounce" : "group-hover:scale-125"}`}
                  />
                  <div className="text-left">
                    <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">
                      AI Neural Calibration
                    </div>
                    <div className="text-[8px] text-white/30 font-mono">
                      {isCalibrating
                        ? "ANALYZING MARKET DRIFT..."
                        : "OPTIMIZE FOR CURRENT ROI"}
                    </div>
                  </div>
                </button>
                <button
                  onClick={() => {
                    alert(
                      "Google Workspace Integration: Please add a CLIENT_ID to .env and configure the Sheets API. Data import logic initialized.",
                    );
                  }}
                  className="w-full mt-4 flex items-center justify-center gap-2 p-4 bg-white/5 border border-white/10 rounded-2xl group hover:border-blue-500/50 transition-all"
                >
                  <Database className="w-4 h-4 text-blue-500 group-hover:scale-110 transition-transform" />
                  <div className="text-left">
                    <div className="text-[10px] font-bold uppercase tracking-widest text-white">
                      Connect Google Base
                    </div>
                    <div className="text-[8px] text-white/30 font-mono">
                      Sync Sheets or SQL via Cloud Link
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 ml-auto text-white/10" />
                </button>
              </div>

              <button
                onClick={() => setShowSettings(false)}
                className="w-full mt-12 py-4 bg-emerald-500 text-black text-xs font-extra-bold tracking-[0.2em] rounded-xl font-bold uppercase hover:bg-emerald-400 transition-colors shadow-[0_0_30px_rgba(16,185,129,0.2)]"
              >
                CALIBRATION COMPLETE
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap');
        
        :root {
          --font-sans: 'Inter', system-ui, sans-serif;
          --font-mono: 'JetBrains Mono', monospace;
        }

        body {
          font-family: var(--font-sans);
          cursor: crosshair;
        }

        ::-webkit-scrollbar {
          width: 4px;
        }
        ::-webkit-scrollbar-track {
          background: transparent;
        }
        ::-webkit-scrollbar-thumb {
          background: rgba(255,255,255,0.1);
          border-radius: 20px;
        }
      `}</style>
      {/* Onboarding Overlay */}
      <AnimatePresence>
        {onboardingStep !== null && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="w-full max-w-lg bg-[#0F0F11] border border-white/10 rounded-[3rem] overflow-hidden relative p-12 text-center"
            >
              <AnimatePresence mode="wait">
                {onboardingStep === 1 && (
                  <motion.div
                    key="step1"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6"
                  >
                    <div className="w-20 h-20 bg-indigo-500/20 rounded-3xl border border-indigo-500/30 flex items-center justify-center mx-auto mb-8">
                      <Zap className="w-10 h-10 text-indigo-400 animate-pulse" />
                    </div>
                    <h2 className="text-3xl font-black tracking-tighter text-white">
                      WELCOME TO THE SINGULARITY
                    </h2>
                    <p className="text-white/60 text-sm leading-relaxed font-mono">
                      You are now connected to a high-fidelity betting
                      orchestration engine. Our core analyzes global liquidity,
                      institutional drift, and neural simulations in real-time.
                    </p>
                    <button
                      onClick={() => setOnboardingStep(2)}
                      className="w-full py-4 bg-indigo-500 text-white rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-indigo-400 transition-all flex items-center justify-center gap-2"
                    >
                      Initialize System <ChevronRight className="w-4 h-4" />
                    </button>
                  </motion.div>
                )}

                {onboardingStep === 2 && (
                  <motion.div
                    key="step2"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6"
                  >
                    <div className="w-20 h-20 bg-emerald-500/20 rounded-3xl border border-emerald-500/30 flex items-center justify-center mx-auto mb-8">
                      <ShieldCheck className="w-10 h-10 text-emerald-400" />
                    </div>
                    <h2 className="text-3xl font-black tracking-tighter text-white">
                      ALPHA SIGNALS
                    </h2>
                    <p className="text-white/60 text-sm leading-relaxed font-mono">
                      Signals are generated when market odds deviate from our
                      neural projections. Look for the "ALPHA" classification
                      for maximum edge.
                    </p>
                    <button
                      onClick={() => setOnboardingStep(3)}
                      className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-emerald-400 transition-all flex items-center justify-center gap-2"
                    >
                      Next Subsystem <ChevronRight className="w-4 h-4" />
                    </button>
                  </motion.div>
                )}

                {onboardingStep === 3 && (
                  <motion.div
                    key="step3"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6"
                  >
                    <div className="w-20 h-20 bg-orange-500/20 rounded-3xl border border-orange-500/30 flex items-center justify-center mx-auto mb-8">
                      <CreditCard className="w-10 h-10 text-orange-400" />
                    </div>
                    <h2 className="text-3xl font-black tracking-tighter text-white">
                      TAX & RESEARCH
                    </h2>
                    <p className="text-white/60 text-sm leading-relaxed font-mono">
                      Use the "Research Quests" to manage follow-ups and "Tax
                      Engine" to keep your liability tracking automated.
                      Compliance is part of the professional edge.
                    </p>
                    <button
                      onClick={async () => {
                        setOnboardingStep(null);
                        if (user) {
                          await setDoc(
                            doc(db, "users", user.uid),
                            { onboardingComplete: true },
                            { merge: true },
                          );
                          voiceService.speak(
                            "System initialization complete. Good luck, Operator.",
                            true,
                          );
                        }
                      }}
                      className="w-full py-4 bg-white text-black rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-white/90 transition-all"
                    >
                      Begin Operations
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
